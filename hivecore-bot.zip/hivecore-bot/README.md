# 🐝 HiveCore Bot

A professional, all-in-one Discord bot integrated with the [Pterodactyl Panel](https://pterodactyl.io/) API. Built with **Node.js + Discord.js v14** and designed to be production-ready, modular, and easy to deploy on a Pterodactyl Node.js egg.

## ✨ Features

- **📡 Node Status Monitoring** — `/nodes` command + auto-updating panel every 3 min in a configured channel.
- **🔐 Pterodactyl Account Generator** — `/genaccount` creates a panel account (random `local@therynzo.in` email) and DMs the credentials privately. Duplicate creation is blocked.
- **🛠️ Server Management** — Start / stop / restart / kill, status (CPU / RAM / Disk progress bars), recent console logs, and a button-based `/manage` control panel. Per-user API keys can be linked via `/link`.
- **🪙 Economy** — Wallet, bank (with deposit/withdraw fees), `/daily` (7-day streak bonus), `/work` (30 min cooldown), `/give`, `/leaderboard`, `/stats`, `/profile`.
- **🎲 Games** — `/coinflip`, `/dice` (5x), `/slots`, `/duel` (button challenge), `/rob` (45 % success), `/spin` (daily wheel).
- **🛒 Shop & Auto-Provisioning** — `/shop` lists Minecraft server plans, `/buy` deducts coins, `/createserver` provisions through the Pterodactyl Application API. One server per user.
- **🚫 Admin Panel** — `/setcoins`, `/addcoins`, `/reset`, `/drop`, `/setchannel`, `/plan add|remove|toggle|list`, `/admin-deleteserver`. Role-based via `OWNER_IDS` + `ADMIN_ROLE_IDS`.
- **📨 Embed-First UX** — Every response is a clean, branded embed with consistent emojis and colours.
- **🔒 Secure** — Slash commands only, ephemeral DMs for credentials, robust error handling, structured Pino logging.
- **💾 Built-in DB** — SQLite via `better-sqlite3` (zero ops). All economy/account/server state persists.

## 📁 Project Structure

```
hivecore-bot/
├── .env.example
├── eslint.config.js
├── package.json
├── README.md
├── data/                       # SQLite database (created automatically)
└── src/
    ├── index.js                # Bot entry point
    ├── deploy-commands.js      # Slash command deployment script
    ├── api/
    │   ├── pterodactyl.js      # Application + Client API wrapper
    │   └── errors.js
    ├── config/
    │   └── config.js           # Loads + validates env
    ├── database/
    │   ├── db.js               # SQLite + schema
    │   ├── users.js            # Wallet / bank / streaks
    │   ├── panelAccounts.js    # Generated panel accounts
    │   ├── userKeys.js         # User-supplied client API keys
    │   ├── servers.js          # Owned servers
    │   ├── plans.js            # Shop plans (seeded with defaults)
    │   ├── purchases.js        # Pending/completed purchases
    │   └── botConfig.js        # Bot key/value config
    ├── events/
    │   ├── ready.js
    │   ├── interactionCreate.js
    │   └── error.js
    ├── tasks/
    │   └── nodeStatus.js       # Auto-refreshing status panel
    ├── utils/
    │   ├── logger.js
    │   ├── embeds.js
    │   ├── helpers.js
    │   ├── cooldowns.js
    │   ├── permissions.js
    │   └── loaders.js
    └── commands/
        ├── account/   (genaccount, link, unlink)
        ├── admin/     (setcoins, addcoins, reset, drop, setchannel, plan, admin-deleteserver)
        ├── bank/      (bank, deposit, withdraw)
        ├── economy/   (balance, daily, work, give, leaderboard, stats, profile)
        ├── games/     (coinflip, dice, slots, duel, rob, spin)
        ├── info/      (help, ping)
        ├── nodes/     (nodes)
        ├── server/    (server-status, server-start/stop/restart/kill, server-console, manage)
        └── shop/      (shop, buy, createserver)
```

## 🚀 Setup

### 1. Prerequisites

- **Node.js ≥ 18** (recommended: 20 LTS)
- A **Discord application** + bot token with the `applications.commands` and `bot` scopes
- A **Pterodactyl Panel** with both an **Application** and **Client** API key

### 2. Install

```bash
git clone https://github.com/therynzo/hivecore-bot.git
cd hivecore-bot
npm install
```

### 3. Configure

```bash
cp .env.example .env
$EDITOR .env
```

Required values:

| Key | Description |
| --- | --- |
| `DISCORD_TOKEN` | Bot token from the Discord Developer Portal |
| `DISCORD_CLIENT_ID` | Application client ID |
| `PTERO_PANEL_URL` | Base URL of your Pterodactyl panel |
| `PTERO_APP_API_KEY` | Application API key (admin → Application API) |
| `PTERO_CLIENT_API_KEY` | Default client API key (used when a user has not linked their own) |

The full set of tunables (economy rates, default egg/nest/location, channel IDs, etc.) is documented in `.env.example`.

### 4. Deploy slash commands

```bash
# Global (takes up to ~1 hour to propagate)
npm run deploy

# Or, for instant testing, set DISCORD_DEV_GUILD_IDS in .env first
DISCORD_DEV_GUILD_IDS=123456789012345678 npm run deploy
```

### 5. Start

```bash
npm start
# or, for auto-restart on file changes
npm run dev
```

### 6. Invite the bot

Use the OAuth2 URL builder in the Discord Developer Portal with scopes `bot` + `applications.commands` and these permissions:

- View Channels, Send Messages, Embed Links, Attach Files
- Read Message History, Use External Emojis
- Manage Messages (optional, for /drop cleanup)

## 🐳 Deploying on a Pterodactyl Node.js Egg

1. Upload the project to your server (or `git clone` from inside the panel file manager / SFTP).
2. Set the **Startup** to `npm start`.
3. Set the **Auto-update on start** flag to install dependencies if your egg supports it; otherwise run `npm install` once via the console.
4. Add the contents of `.env` as **Startup Variables**, or upload `.env` as a file.
5. Deploy slash commands once (`node src/deploy-commands.js` from the console).

## 🔧 Admin Workflow

```
/setchannel type:Node status auto-update channel:#status     # post & maintain status panel
/plan add key:starter name:"Starter Plan" price:300 ram:1024 cpu:100 disk:10240 emoji:🌱
/plan toggle key:starter enabled:true
/addcoins user:@SomeUser amount:1000
```

## 🩹 Error Handling

- All command failures are caught at the `interactionCreate` boundary and replied with a red embed.
- Pterodactyl errors are extracted via `src/api/errors.js` and surfaced verbatim (so users see "Insufficient resources on the node", etc.).
- Unhandled promise rejections and uncaught exceptions are logged via Pino with full stacks but **never crash the bot**.

## 🔐 Security Notes

- `genaccount` DMs credentials only and stores password hashes server-side via Pterodactyl (we never persist plaintext passwords).
- User-linked API keys are stored in SQLite. Restrict OS-level access to the `data/` directory in production.
- The bot **never logs tokens or API keys**.

## 📜 License

MIT
