'use strict';

const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { config, validateRequired } = require('./config/config');
const logger = require('./utils/logger');
const { loadCommands, loadEvents } = require('./utils/loaders');

// Touch DB so schema is initialised on boot even before the first command.
require('./database/db');

async function main() {
  const missing = validateRequired();
  if (missing.length > 0) {
    logger.fatal({ missing }, 'missing required environment variables; aborting');
    process.exit(1);
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.DirectMessages,
    ],
    partials: [Partials.Channel],
  });

  client.config = config;
  client.logger = logger;

  loadCommands(client);
  loadEvents(client);

  process.on('unhandledRejection', (err) => {
    logger.error({ err: err?.message || err, stack: err?.stack }, 'unhandledRejection');
  });
  process.on('uncaughtException', (err) => {
    logger.error({ err: err?.message || err, stack: err?.stack }, 'uncaughtException');
  });

  await client.login(config.discord.token);
}

main().catch((err) => {
  logger.fatal({ err: err?.message || err, stack: err?.stack }, 'fatal startup error');
  process.exit(1);
});
