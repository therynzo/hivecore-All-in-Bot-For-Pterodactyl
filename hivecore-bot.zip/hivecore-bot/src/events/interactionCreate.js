'use strict';

const logger = require('../utils/logger');
const embeds = require('../utils/embeds');

async function safeReply(interaction, payload) {
  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(payload);
    } else {
      await interaction.reply({ ...payload, ephemeral: true });
    }
  } catch (err) {
    logger.error({ err: err.message }, 'failed to reply to interaction');
  }
}

module.exports = {
  name: 'interactionCreate',
  async execute(client, interaction) {
    try {
      if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) {
          await safeReply(interaction, {
            embeds: [embeds.error('Unknown command', 'This command is not registered.')],
          });
          return;
        }
        await command.execute(interaction, client);
        return;
      }

      if (interaction.isAutocomplete()) {
        const command = client.commands.get(interaction.commandName);
        if (command?.autocomplete) {
          await command.autocomplete(interaction, client);
        }
        return;
      }

      if (interaction.isButton() || interaction.isStringSelectMenu()) {
        // Route by customId prefix, e.g. "shop:buy:starter".
        const [scope] = (interaction.customId || '').split(':');
        const handler = client.commands.get(scope);
        if (handler?.handleComponent) {
          await handler.handleComponent(interaction, client);
          return;
        }
      }
    } catch (err) {
      logger.error(
        { command: interaction.commandName, err: err?.message || err, stack: err?.stack },
        'command execution failed',
      );
      await safeReply(interaction, {
        embeds: [embeds.error('Something went wrong', err?.message || 'Please try again later.')],
      });
    }
  },
};
