'use strict';

const { ActivityType } = require('discord.js');
const logger = require('../utils/logger');
const nodeStatus = require('../tasks/nodeStatus');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    logger.info({ user: client.user.tag, guilds: client.guilds.cache.size }, 'bot online');
    client.user.setPresence({
      activities: [{ name: '/help • HiveCore', type: ActivityType.Watching }],
      status: 'online',
    });

    nodeStatus.start(client);
  },
};
