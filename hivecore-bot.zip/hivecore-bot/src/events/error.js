'use strict';

const logger = require('../utils/logger');

module.exports = {
  name: 'error',
  execute(_client, err) {
    logger.error({ err: err?.message || err }, 'discord client error');
  },
};
