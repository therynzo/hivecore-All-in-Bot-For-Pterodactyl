'use strict';

const ptero = require('../api/pterodactyl');
const embeds = require('../utils/embeds');
const botConfig = require('../database/botConfig');
const { config } = require('../config/config');
const logger = require('../utils/logger');
const { progressBar } = require('../utils/helpers');

async function buildNodeStatusEmbed() {
  let nodes;
  try {
    nodes = await ptero.listNodes();
  } catch (err) {
    return embeds.error('Failed to load nodes', err.message || 'Unknown error');
  }

  const embed = embeds
    .brand('📡 HiveCore Node Status')
    .setDescription(
      nodes.length === 0
        ? '_No nodes registered._'
        : `Tracking **${nodes.length}** node(s) — refreshes every ${config.bot.nodeStatusIntervalMin} minutes.`,
    );

  for (const node of nodes.slice(0, 25)) {
    const a = node.attributes;
    let online = false;
    let ramPct = 0;
    let detail = '';
    try {
      // Pterodactyl exposes node-level allocated resources via /nodes/:id.
      // The Application API does not return live CPU; we surface allocated RAM/Disk instead.
      const info = await ptero.getNode(a.id);
      const memTotal = info.attributes?.memory || 1;
      const diskTotal = info.attributes?.disk || 1;
      const memUsed = info.attributes?.allocated_resources?.memory || 0;
      const diskUsed = info.attributes?.allocated_resources?.disk || 0;
      ramPct = Math.min(100, (memUsed / memTotal) * 100);
      online = true;
      detail =
        `🧠 **RAM:** ${progressBar(ramPct)} ${memUsed}/${memTotal} MB\n` +
        `💽 **Disk:** ${progressBar((diskUsed / diskTotal) * 100)} ${diskUsed}/${diskTotal} MB`;
    } catch (err) {
      online = false;
      detail = `⚠️ ${err.response?.status || 'unreachable'}`;
    }
    embed.addFields({
      name: `${online ? '🟢' : '🔴'} ${a.name}`,
      value: detail,
      inline: false,
    });
  }
  embed.setTimestamp();
  return embed;
}

let timer = null;

async function tick(client) {
  try {
    const channelId = botConfig.get('node_status_channel_id') || config.bot.nodeStatusChannelId;
    if (!channelId) return;
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (!channel) return;

    const embed = await buildNodeStatusEmbed();
    const messageId = botConfig.get('node_status_message_id');
    if (messageId) {
      try {
        const msg = await channel.messages.fetch(messageId);
        await msg.edit({ embeds: [embed] });
        return;
      } catch {
        // Stale message; fall through to send a fresh one.
      }
    }
    const sent = await channel.send({ embeds: [embed] });
    botConfig.set('node_status_message_id', sent.id);
  } catch (err) {
    logger.error({ err: err.message }, 'node status tick failed');
  }
}

function start(client) {
  if (timer) clearInterval(timer);
  const intervalMs = Math.max(1, config.bot.nodeStatusIntervalMin) * 60 * 1000;
  timer = setInterval(() => tick(client).catch(() => {}), intervalMs);
  // Run once shortly after startup.
  setTimeout(() => tick(client).catch(() => {}), 5000);
  logger.info({ intervalMs }, 'node status updater started');
}

function stop() {
  if (timer) {
    clearInterval(timer);
    timer = null;
  }
}

module.exports = { buildNodeStatusEmbed, start, stop };
