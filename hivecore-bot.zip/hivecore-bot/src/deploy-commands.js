'use strict';

const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const { config, validateRequired } = require('./config/config');
const logger = require('./utils/logger');

function collectCommandData() {
  const data = [];
  const root = path.join(__dirname, 'commands');
  for (const category of fs.readdirSync(root)) {
    const dir = path.join(root, category);
    if (!fs.statSync(dir).isDirectory()) continue;
    for (const file of fs.readdirSync(dir)) {
      if (!file.endsWith('.js')) continue;
      const command = require(path.join(dir, file));
      if (command?.data?.toJSON) {
        data.push(command.data.toJSON());
      }
    }
  }
  return data;
}

async function main() {
  const missing = validateRequired();
  if (missing.length > 0) {
    logger.fatal({ missing }, 'missing required env; aborting deploy');
    process.exit(1);
  }
  const commands = collectCommandData();
  const rest = new REST({ version: '10' }).setToken(config.discord.token);

  if (config.discord.devGuildIds.length === 0) {
    logger.info({ count: commands.length }, 'deploying commands globally');
    await rest.put(Routes.applicationCommands(config.discord.clientId), { body: commands });
    logger.info('global commands deployed (may take up to 1 hour to propagate)');
    return;
  }

  for (const guildId of config.discord.devGuildIds) {
    logger.info({ guildId, count: commands.length }, 'deploying commands to guild');
    await rest.put(
      Routes.applicationGuildCommands(config.discord.clientId, guildId),
      { body: commands },
    );
  }
  logger.info('guild commands deployed');
}

main().catch((err) => {
  logger.fatal({ err: err?.message || err }, 'failed to deploy commands');
  process.exit(1);
});
