'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { randomInt } = require('../../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dice')
    .setDescription('Guess the dice (5x payout)')
    .addIntegerOption((o) =>
      o.setName('guess').setDescription('Your guess 1-6').setMinValue(1).setMaxValue(6).setRequired(true),
    )
    .addIntegerOption((o) =>
      o.setName('amount').setDescription('Amount to bet').setMinValue(1).setRequired(true),
    ),
  async execute(interaction) {
    const guess = interaction.options.getInteger('guess');
    const amount = interaction.options.getInteger('amount');
    const u = users.getUser(interaction.user.id);
    if (amount > u.wallet) {
      await interaction.reply({
        embeds: [embeds.error('Insufficient funds', `Wallet: ${embeds.formatCoins(u.wallet)}`)],
        ephemeral: true,
      });
      return;
    }

    const roll = randomInt(1, 6);
    if (roll === guess) {
      const win = amount * 5;
      users.addCoins(interaction.user.id, win - amount);
      await interaction.reply({
        embeds: [
          embeds.success(
            `🎲 You rolled ${roll} — Correct!`,
            `5x payout: +${embeds.formatCoins(win - amount)} net (returned ${embeds.formatCoins(win)}).`,
          ),
        ],
      });
    } else {
      users.addCoins(interaction.user.id, -amount);
      await interaction.reply({
        embeds: [
          embeds.error(
            `🎲 You rolled ${roll} — Wrong!`,
            `You lost ${embeds.formatCoins(amount)}.`,
          ),
        ],
      });
    }
  },
};
