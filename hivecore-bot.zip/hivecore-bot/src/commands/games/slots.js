'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { randomElement } = require('../../utils/helpers');

const SYMBOLS = ['🍒', '🍋', '🍇', '🔔', '⭐', '💎'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slots')
    .setDescription('Spin the slot machine')
    .addIntegerOption((o) =>
      o.setName('amount').setDescription('Amount to bet').setMinValue(1).setRequired(true),
    ),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const u = users.getUser(interaction.user.id);
    if (amount > u.wallet) {
      await interaction.reply({
        embeds: [embeds.error('Insufficient funds', `Wallet: ${embeds.formatCoins(u.wallet)}`)],
        ephemeral: true,
      });
      return;
    }

    const reels = [randomElement(SYMBOLS), randomElement(SYMBOLS), randomElement(SYMBOLS)];
    const display = `┃ ${reels.join(' ┃ ')} ┃`;

    let multiplier = 0;
    if (reels[0] === reels[1] && reels[1] === reels[2]) {
      multiplier = reels[0] === '💎' ? 10 : 5;
    } else if (reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2]) {
      multiplier = 2;
    }

    if (multiplier > 0) {
      const win = amount * multiplier;
      users.addCoins(interaction.user.id, win - amount);
      await interaction.reply({
        embeds: [
          embeds.success(
            `🎰 ${multiplier}x Win!`,
            `${display}\nYou won ${embeds.formatCoins(win - amount)} net.`,
          ),
        ],
      });
    } else {
      users.addCoins(interaction.user.id, -amount);
      await interaction.reply({
        embeds: [
          embeds.error('🎰 No match', `${display}\nYou lost ${embeds.formatCoins(amount)}.`),
        ],
      });
    }
  },
};
