'use strict';

const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
} = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('duel')
    .setDescription('Challenge someone to a duel — winner takes the pot')
    .addUserOption((o) => o.setName('user').setDescription('Opponent').setRequired(true))
    .addIntegerOption((o) =>
      o.setName('bet').setDescription('Coins each player wagers').setMinValue(1).setRequired(true),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const bet = interaction.options.getInteger('bet');

    if (target.bot || target.id === interaction.user.id) {
      await interaction.reply({
        embeds: [embeds.error('Invalid opponent', 'Pick another human.')],
        ephemeral: true,
      });
      return;
    }

    const challenger = users.getUser(interaction.user.id);
    const opponent = users.getUser(target.id);
    if (challenger.wallet < bet) {
      await interaction.reply({
        embeds: [embeds.error('You can\'t cover the bet', `Your wallet: ${embeds.formatCoins(challenger.wallet)}`)],
        ephemeral: true,
      });
      return;
    }
    if (opponent.wallet < bet) {
      await interaction.reply({
        embeds: [embeds.error('Opponent can\'t cover the bet', `${target.username}'s wallet: ${embeds.formatCoins(opponent.wallet)}`)],
        ephemeral: true,
      });
      return;
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('duel:accept').setStyle(ButtonStyle.Success).setLabel('Accept'),
      new ButtonBuilder().setCustomId('duel:reject').setStyle(ButtonStyle.Danger).setLabel('Reject'),
    );

    const challenge = embeds
      .brand('⚔️ Duel Challenge')
      .setDescription(
        `${interaction.user} has challenged ${target} to a duel for ${embeds.formatCoins(bet)} each. Winner takes ${embeds.formatCoins(bet * 2)}!`,
      );

    const message = await interaction.reply({
      content: `${target}`,
      embeds: [challenge],
      components: [row],
      fetchReply: true,
    });

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60_000,
      filter: (i) => i.user.id === target.id,
    });

    collector.on('collect', async (i) => {
      if (i.customId === 'duel:reject') {
        await i.update({
          embeds: [embeds.warn('Duel declined', `${target.username} declined the challenge.`)],
          components: [],
        });
        collector.stop('rejected');
        return;
      }

      // Re-validate balances at execution time.
      const a = users.getUser(interaction.user.id);
      const b = users.getUser(target.id);
      if (a.wallet < bet || b.wallet < bet) {
        await i.update({
          embeds: [embeds.error('Duel cancelled', 'One of the players no longer has enough coins.')],
          components: [],
        });
        collector.stop('insufficient');
        return;
      }

      const winner = Math.random() < 0.5 ? interaction.user : target;
      const loser = winner.id === interaction.user.id ? target : interaction.user;
      users.addCoins(winner.id, bet);
      users.addCoins(loser.id, -bet);

      await i.update({
        embeds: [
          embeds.success(
            '🏆 Duel Complete',
            `${winner} won ${embeds.formatCoins(bet * 2)} (gross) — ${embeds.formatCoins(bet)} from ${loser}.`,
          ),
        ],
        components: [],
      });
      collector.stop('done');
    });

    collector.on('end', async (_, reason) => {
      if (reason === 'time') {
        await message.edit({
          embeds: [embeds.warn('Duel expired', 'The challenge timed out.')],
          components: [],
        });
      }
    });
  },
};
