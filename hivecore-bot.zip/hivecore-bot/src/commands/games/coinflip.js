'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('50/50 coin flip — double or nothing')
    .addStringOption((o) =>
      o.setName('amount').setDescription('Amount or "all"').setRequired(true),
    )
    .addStringOption((o) =>
      o
        .setName('side')
        .setDescription('Heads or Tails')
        .addChoices({ name: 'Heads', value: 'heads' }, { name: 'Tails', value: 'tails' })
        .setRequired(true),
    ),
  async execute(interaction) {
    const raw = interaction.options.getString('amount').toLowerCase();
    const side = interaction.options.getString('side');
    const u = users.getUser(interaction.user.id);

    let amount;
    if (raw === 'all') amount = u.wallet;
    else amount = parseInt(raw, 10);
    if (!Number.isFinite(amount) || amount <= 0) {
      await interaction.reply({
        embeds: [embeds.error('Invalid amount', 'Provide a positive integer or `all`.')],
        ephemeral: true,
      });
      return;
    }
    if (amount > u.wallet) {
      await interaction.reply({
        embeds: [embeds.error('Insufficient funds', `Wallet: ${embeds.formatCoins(u.wallet)}`)],
        ephemeral: true,
      });
      return;
    }

    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const won = result === side;
    if (won) users.addCoins(interaction.user.id, amount);
    else users.addCoins(interaction.user.id, -amount);

    const embed = won
      ? embeds.success(
          `🎉 ${result.toUpperCase()} — You won!`,
          `You doubled your bet and gained ${embeds.formatCoins(amount)}.`,
        )
      : embeds.error(
          `💀 ${result.toUpperCase()} — You lost!`,
          `You lost ${embeds.formatCoins(amount)}.`,
        );
    await interaction.reply({ embeds: [embed] });
  },
};
