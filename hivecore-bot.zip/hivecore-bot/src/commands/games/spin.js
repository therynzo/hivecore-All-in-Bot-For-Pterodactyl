'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { randomInt, randomElement } = require('../../utils/helpers');
const { formatDuration } = require('../../utils/cooldowns');

const ONE_DAY = 24 * 60 * 60 * 1000;

const PRIZES = [
  { label: '🪙 Tiny prize',   min: 10,   max: 50,   weight: 5 },
  { label: '💰 Small prize',  min: 50,   max: 150,  weight: 4 },
  { label: '💵 Medium prize', min: 150,  max: 400,  weight: 2 },
  { label: '💎 Big prize',    min: 400,  max: 800,  weight: 1 },
  { label: '🔥 Jackpot!',     min: 1000, max: 2000, weight: 1 },
];

function weightedPick(prizes) {
  const total = prizes.reduce((s, p) => s + p.weight, 0);
  let r = Math.random() * total;
  for (const p of prizes) {
    r -= p.weight;
    if (r <= 0) return p;
  }
  return randomElement(prizes);
}

module.exports = {
  data: new SlashCommandBuilder().setName('spin').setDescription('Spin the daily prize wheel'),
  async execute(interaction) {
    const u = users.getUser(interaction.user.id);
    const elapsed = Date.now() - (u.last_spin || 0);
    if (elapsed < ONE_DAY) {
      await interaction.reply({
        embeds: [embeds.warn('Already spun', `Come back in **${formatDuration(ONE_DAY - elapsed)}**.`)],
        ephemeral: true,
      });
      return;
    }

    const prize = weightedPick(PRIZES);
    const amount = randomInt(prize.min, prize.max);
    users.addCoins(interaction.user.id, amount);
    users.recordSpin(interaction.user.id);

    await interaction.reply({
      embeds: [
        embeds
          .brand('🎡 Daily Prize Wheel')
          .setDescription(`${prize.label}\nYou received ${embeds.formatCoins(amount)}!`),
      ],
    });
  },
};
