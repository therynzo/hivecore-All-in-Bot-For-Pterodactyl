'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');
const { formatDuration } = require('../../utils/cooldowns');
const { randomInt } = require('../../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rob')
    .setDescription('Steal wallet coins from another user (45% success, 30 min CD)')
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    if (target.bot || target.id === interaction.user.id) {
      await interaction.reply({
        embeds: [embeds.error('Invalid target', 'You cannot rob yourself or a bot.')],
        ephemeral: true,
      });
      return;
    }

    const robber = users.getUser(interaction.user.id);
    const cooldown = config.economy.robCooldownMin * 60 * 1000;
    const elapsed = Date.now() - (robber.last_rob || 0);
    if (elapsed < cooldown) {
      await interaction.reply({
        embeds: [
          embeds.warn(
            'Cooling off',
            `Try again in **${formatDuration(cooldown - elapsed)}**.`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    const victim = users.getUser(target.id);
    if (victim.wallet < 50) {
      await interaction.reply({
        embeds: [
          embeds.error(
            'Pockets are empty',
            `${target.username} doesn't have enough wallet coins to rob (need ≥ 50).`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    users.recordRob(interaction.user.id);
    const success = Math.random() < config.economy.robSuccessRate;
    if (success) {
      const stolen = randomInt(Math.floor(victim.wallet * 0.1), Math.floor(victim.wallet * 0.4));
      users.addCoins(target.id, -stolen);
      users.addCoins(interaction.user.id, stolen);
      await interaction.reply({
        embeds: [
          embeds.success(
            '🥷 Successful robbery',
            `You stole ${embeds.formatCoins(stolen)} from ${target}.`,
          ),
        ],
      });
    } else {
      const fine = Math.min(robber.wallet, randomInt(50, 200));
      users.addCoins(interaction.user.id, -fine);
      await interaction.reply({
        embeds: [
          embeds.error(
            '🚓 Caught!',
            `You were caught trying to rob ${target} and fined ${embeds.formatCoins(fine)}.`,
          ),
        ],
      });
    }
  },
};
