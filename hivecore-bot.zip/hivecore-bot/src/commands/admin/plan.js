'use strict';

const { SlashCommandBuilder } = require('discord.js');
const plans = require('../../database/plans');
const embeds = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('plan')
    .setDescription('[Admin] Manage shop plans')
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Add or update a shop plan')
        .addStringOption((o) => o.setName('key').setDescription('Plan key (e.g. starter)').setRequired(true))
        .addStringOption((o) => o.setName('name').setDescription('Display name').setRequired(true))
        .addIntegerOption((o) => o.setName('price').setDescription('Price in coins').setRequired(true).setMinValue(1))
        .addIntegerOption((o) => o.setName('ram').setDescription('RAM in MB').setRequired(true).setMinValue(128))
        .addIntegerOption((o) => o.setName('cpu').setDescription('CPU (% of one core, e.g. 100 = 1 core)').setRequired(true).setMinValue(10))
        .addIntegerOption((o) => o.setName('disk').setDescription('Disk in MB').setRequired(true).setMinValue(512))
        .addStringOption((o) => o.setName('emoji').setDescription('Emoji icon').setRequired(false)),
    )
    .addSubcommand((s) =>
      s
        .setName('remove')
        .setDescription('Delete a plan')
        .addStringOption((o) => o.setName('key').setDescription('Plan key').setRequired(true).setAutocomplete(true)),
    )
    .addSubcommand((s) =>
      s
        .setName('toggle')
        .setDescription('Enable or disable a plan')
        .addStringOption((o) => o.setName('key').setDescription('Plan key').setRequired(true).setAutocomplete(true))
        .addBooleanOption((o) => o.setName('enabled').setDescription('Enabled?').setRequired(true)),
    )
    .addSubcommand((s) => s.setName('list').setDescription('List all plans')),
  async autocomplete(interaction) {
    const focused = interaction.options.getFocused().toLowerCase();
    const list = plans
      .listAll()
      .filter((p) => !focused || p.plan_key.includes(focused))
      .slice(0, 25)
      .map((p) => ({ name: `${p.emoji} ${p.name} (${p.plan_key})`, value: p.plan_key }));
    await interaction.respond(list);
  },
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      await interaction.reply({ embeds: [embeds.error('Forbidden', 'Admin only.')], ephemeral: true });
      return;
    }

    const sub = interaction.options.getSubcommand();
    if (sub === 'add') {
      const data = {
        plan_key: interaction.options.getString('key').toLowerCase(),
        name: interaction.options.getString('name'),
        price: interaction.options.getInteger('price'),
        ram: interaction.options.getInteger('ram'),
        cpu: interaction.options.getInteger('cpu'),
        disk: interaction.options.getInteger('disk'),
        emoji: interaction.options.getString('emoji') || '🌱',
        enabled: 1,
      };
      plans.save(data);
      await interaction.reply({
        embeds: [embeds.success('Plan saved', `Plan **${data.name}** (\`${data.plan_key}\`) saved.`)],
      });
      return;
    }
    if (sub === 'remove') {
      const key = interaction.options.getString('key').toLowerCase();
      plans.remove(key);
      await interaction.reply({ embeds: [embeds.success('Plan removed', `\`${key}\` deleted.`)] });
      return;
    }
    if (sub === 'toggle') {
      const key = interaction.options.getString('key').toLowerCase();
      const enabled = interaction.options.getBoolean('enabled');
      plans.toggle(key, enabled);
      await interaction.reply({
        embeds: [embeds.success('Plan updated', `\`${key}\` is now ${enabled ? 'enabled' : 'disabled'}.`)],
      });
      return;
    }
    if (sub === 'list') {
      const list = plans.listAll();
      const embed = embeds.brand('🛒 All Shop Plans');
      if (list.length === 0) {
        embed.setDescription('_No plans configured._');
      } else {
        for (const p of list) {
          embed.addFields({
            name: `${p.emoji} ${p.name} (${p.plan_key}) ${p.enabled ? '' : '🚫'}`,
            value: `Price ${p.price} • ${p.ram}MB RAM • ${p.cpu}% CPU • ${p.disk}MB Disk`,
            inline: false,
          });
        }
      }
      await interaction.reply({ embeds: [embed] });
    }
  },
};
