'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../../api/pterodactyl');
const { describePteroError } = require('../../api/errors');
const servers = require('../../database/servers');
const embeds = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin-deleteserver')
    .setDescription("[Admin] Delete a user's server from the panel")
    .addUserOption((o) => o.setName('user').setDescription('Owner').setRequired(true))
    .addBooleanOption((o) => o.setName('force').setDescription('Force delete')),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      await interaction.reply({ embeds: [embeds.error('Forbidden', 'Admin only.')], ephemeral: true });
      return;
    }
    const target = interaction.options.getUser('user');
    const force = interaction.options.getBoolean('force') || false;
    const owned = servers.firstForUser(target.id);
    if (!owned) {
      await interaction.reply({
        embeds: [embeds.error('No server', `${target} doesn't own a tracked server.`)],
        ephemeral: true,
      });
      return;
    }
    await interaction.deferReply({ ephemeral: true });
    try {
      await ptero.deleteServer(owned.panel_server_id, force);
      servers.removeByPanelId(owned.panel_server_id);
      await interaction.editReply({
        embeds: [embeds.success('Deleted', `Removed server \`${owned.identifier}\` belonging to ${target}.`)],
      });
    } catch (err) {
      await interaction.editReply({
        embeds: [embeds.error('Delete failed', describePteroError(err))],
      });
    }
  },
};
