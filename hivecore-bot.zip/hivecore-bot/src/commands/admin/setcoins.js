'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setcoins')
    .setDescription("[Admin] Set a user's wallet balance")
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true))
    .addIntegerOption((o) =>
      o.setName('amount').setDescription('New wallet balance').setMinValue(0).setRequired(true),
    ),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      await interaction.reply({ embeds: [embeds.error('Forbidden', 'Admin only.')], ephemeral: true });
      return;
    }
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    users.setCoins(target.id, amount);
    await interaction.reply({
      embeds: [embeds.success('Done', `Set ${target}'s wallet to ${embeds.formatCoins(amount)}.`)],
    });
  },
};
