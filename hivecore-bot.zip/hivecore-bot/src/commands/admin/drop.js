'use strict';

const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
} = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('drop')
    .setDescription('[Admin] Drop coins for the first user to claim')
    .addIntegerOption((o) =>
      o.setName('amount').setDescription('Amount to drop').setMinValue(1).setRequired(true),
    ),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      await interaction.reply({ embeds: [embeds.error('Forbidden', 'Admin only.')], ephemeral: true });
      return;
    }
    const amount = interaction.options.getInteger('amount');
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('drop:claim').setLabel('Claim!').setEmoji('🎁').setStyle(ButtonStyle.Success),
    );

    const message = await interaction.reply({
      embeds: [
        embeds
          .brand('🎁 Coin Drop!')
          .setDescription(`First to click claims ${embeds.formatCoins(amount)}!`),
      ],
      components: [row],
      fetchReply: true,
    });

    let claimed = false;
    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60_000,
    });
    collector.on('collect', async (i) => {
      if (claimed) {
        await i.reply({
          embeds: [embeds.warn('Too slow', 'Someone already claimed it.')],
          ephemeral: true,
        });
        return;
      }
      claimed = true;
      users.addCoins(i.user.id, amount);
      await i.update({
        embeds: [
          embeds.success(
            '🎁 Drop Claimed!',
            `${i.user} grabbed ${embeds.formatCoins(amount)}!`,
          ),
        ],
        components: [],
      });
      collector.stop('claimed');
    });
    collector.on('end', async (_, reason) => {
      if (reason !== 'claimed') {
        await message.edit({
          embeds: [embeds.warn('Drop expired', `No one claimed ${embeds.formatCoins(amount)}.`)],
          components: [],
        });
      }
    });
  },
};
