'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addcoins')
    .setDescription('[Admin] Add coins to a user (use negative to remove)')
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true))
    .addIntegerOption((o) =>
      o.setName('amount').setDescription('Coins to add (can be negative)').setRequired(true),
    ),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      await interaction.reply({ embeds: [embeds.error('Forbidden', 'Admin only.')], ephemeral: true });
      return;
    }
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    users.addCoins(target.id, amount);
    const fresh = users.getUser(target.id);
    await interaction.reply({
      embeds: [
        embeds.success(
          'Done',
          `${amount >= 0 ? 'Added' : 'Removed'} ${embeds.formatCoins(Math.abs(amount))} ${
            amount >= 0 ? 'to' : 'from'
          } ${target}. New wallet: ${embeds.formatCoins(fresh.wallet)}.`,
        ),
      ],
    });
  },
};
