'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reset')
    .setDescription("[Admin] Reset a user's wallet & bank to 0")
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true)),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      await interaction.reply({ embeds: [embeds.error('Forbidden', 'Admin only.')], ephemeral: true });
      return;
    }
    const target = interaction.options.getUser('user');
    users.setCoins(target.id, 0);
    users.setBankCoins(target.id, 0);
    await interaction.reply({
      embeds: [embeds.success('Done', `${target}'s coins have been reset.`)],
    });
  },
};
