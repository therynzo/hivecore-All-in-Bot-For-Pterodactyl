'use strict';

const { SlashCommandBuilder, ChannelType } = require('discord.js');
const botConfig = require('../../database/botConfig');
const embeds = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');

const KEY_MAP = {
  'node-status': 'node_status_channel_id',
  log: 'log_channel_id',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setchannel')
    .setDescription('[Admin] Configure log/status channels')
    .addStringOption((o) =>
      o
        .setName('type')
        .setDescription('Which channel to configure')
        .addChoices(
          { name: 'Node status auto-update', value: 'node-status' },
          { name: 'Log channel', value: 'log' },
        )
        .setRequired(true),
    )
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Target channel')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true),
    ),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      await interaction.reply({ embeds: [embeds.error('Forbidden', 'Admin only.')], ephemeral: true });
      return;
    }
    const type = interaction.options.getString('type');
    const channel = interaction.options.getChannel('channel');
    const dbKey = KEY_MAP[type];
    botConfig.set(dbKey, channel.id);
    if (type === 'node-status') botConfig.remove('node_status_message_id');
    await interaction.reply({
      embeds: [embeds.success('Channel set', `**${type}** channel is now ${channel}.`)],
    });
  },
};
