'use strict';

const { SlashCommandBuilder } = require('discord.js');
const plans = require('../../database/plans');
const purchases = require('../../database/purchases');
const users = require('../../database/users');
const servers = require('../../database/servers');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Purchase a Minecraft server plan with coins')
    .addStringOption((o) =>
      o.setName('plan').setDescription('Plan key (e.g. starter)').setRequired(true).setAutocomplete(true),
    ),
  async autocomplete(interaction) {
    const focused = interaction.options.getFocused().toLowerCase();
    const list = plans
      .listEnabled()
      .filter((p) => !focused || p.plan_key.toLowerCase().includes(focused) || p.name.toLowerCase().includes(focused))
      .slice(0, 25)
      .map((p) => ({ name: `${p.emoji} ${p.name} — ${p.price} coins`, value: p.plan_key }));
    await interaction.respond(list);
  },
  async execute(interaction) {
    const planKey = interaction.options.getString('plan').toLowerCase();
    const plan = plans.get(planKey);
    if (!plan || !plan.enabled) {
      await interaction.reply({
        embeds: [embeds.error('Plan not found', `No active plan with key \`${planKey}\`.`)],
        ephemeral: true,
      });
      return;
    }

    // One server per user.
    if (servers.firstForUser(interaction.user.id)) {
      await interaction.reply({
        embeds: [embeds.error('Already own a server', 'Each user can only own one server.')],
        ephemeral: true,
      });
      return;
    }

    const u = users.getUser(interaction.user.id);
    if (u.wallet < plan.price) {
      await interaction.reply({
        embeds: [
          embeds.error(
            'Insufficient coins',
            `Need ${embeds.formatCoins(plan.price)}, you have ${embeds.formatCoins(u.wallet)}.`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    users.addCoins(interaction.user.id, -plan.price);
    purchases.create(interaction.user.id, plan.plan_key, plan.price);

    await interaction.reply({
      embeds: [
        embeds
          .success(
            'Purchase confirmed!',
            `You bought **${plan.emoji} ${plan.name}** for ${embeds.formatCoins(plan.price)}.\n\n` +
              `Now run \`/createserver plan:${plan.plan_key}\` to deploy it.`,
          ),
      ],
    });
  },
};
