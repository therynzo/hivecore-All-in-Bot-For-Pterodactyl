'use strict';

const { SlashCommandBuilder } = require('discord.js');
const plans = require('../../database/plans');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder().setName('shop').setDescription('Browse available Minecraft server plans'),
  async execute(interaction) {
    const list = plans.listEnabled();
    const embed = embeds
      .brand('🛒 HiveCore Server Shop')
      .setDescription(
        `Purchase a **Minecraft server** using your ${config.branding.coinSymbol}!\n\n` +
          '⚠️ **One server per user** — choose wisely.\n' +
          '» Use `/buy plan:<plan>` to purchase a plan.',
      );

    if (list.length === 0) {
      embed.addFields({ name: '\u200b', value: '_No plans available. An admin must add some._' });
    } else {
      for (const p of list) {
        embed.addFields({
          name: `${p.emoji} ${p.name}`,
          value:
            `${config.branding.coinEmoji} **${p.price.toLocaleString('en-US')} coins**\n` +
            `🧠 **RAM:** ${(p.ram / 1024).toFixed(p.ram % 1024 ? 1 : 0)}GB\n` +
            `⚙️ **CPU:** ${p.cpu / 100} Core(s)\n` +
            `💽 **Disk:** ${(p.disk / 1024).toFixed(p.disk % 1024 ? 1 : 0)}GB`,
          inline: false,
        });
      }
    }
    await interaction.reply({ embeds: [embed] });
  },
};
