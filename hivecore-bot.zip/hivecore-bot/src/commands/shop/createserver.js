'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../../api/pterodactyl');
const { describePteroError } = require('../../api/errors');
const plans = require('../../database/plans');
const purchases = require('../../database/purchases');
const panelAccounts = require('../../database/panelAccounts');
const servers = require('../../database/servers');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('createserver')
    .setDescription('Deploy your purchased server')
    .addStringOption((o) =>
      o.setName('plan').setDescription('Plan key from your purchase').setRequired(true).setAutocomplete(true),
    )
    .addStringOption((o) => o.setName('name').setDescription('Server name').setRequired(false)),
  async autocomplete(interaction) {
    const userPurchases = purchases.listForUser(interaction.user.id).filter((p) => !p.panel_server_id);
    const list = userPurchases
      .map((p) => plans.get(p.plan_key))
      .filter(Boolean)
      .slice(0, 25)
      .map((p) => ({ name: `${p.emoji} ${p.name}`, value: p.plan_key }));
    await interaction.respond(list);
  },
  async execute(interaction) {
    const planKey = interaction.options.getString('plan').toLowerCase();
    const customName = interaction.options.getString('name');
    const plan = plans.get(planKey);
    if (!plan) {
      await interaction.reply({
        embeds: [embeds.error('Plan not found', `Unknown plan: \`${planKey}\``)],
        ephemeral: true,
      });
      return;
    }

    if (servers.firstForUser(interaction.user.id)) {
      await interaction.reply({
        embeds: [embeds.error('Already own a server', 'Each user can only own one server.')],
        ephemeral: true,
      });
      return;
    }

    const pendingPurchase = purchases
      .listForUser(interaction.user.id)
      .find((p) => p.plan_key === planKey && !p.panel_server_id);
    if (!pendingPurchase) {
      await interaction.reply({
        embeds: [embeds.error('No purchase found', `Buy this plan first using \`/buy plan:${planKey}\`.`)],
        ephemeral: true,
      });
      return;
    }

    const account = panelAccounts.getByDiscord(interaction.user.id);
    if (!account) {
      await interaction.reply({
        embeds: [
          embeds.error(
            'No panel account',
            'Generate a panel account first using `/genaccount`.',
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      // Find a free allocation in the configured location.
      const found = await ptero.findAllocationOnAnyNodeInLocation(config.pterodactyl.defaultLocationId);
      if (!found) {
        await interaction.editReply({
          embeds: [
            embeds.error(
              'No free allocation',
              `No free allocation found in location ${config.pterodactyl.defaultLocationId}. Ask an admin to add one.`,
            ),
          ],
        });
        return;
      }

      const serverName = customName || `${interaction.user.username}-${plan.plan_key}`;
      const payload = {
        name: serverName,
        user: account.panel_user_id,
        egg: config.pterodactyl.defaultEggId,
        docker_image: config.pterodactyl.defaultDockerImage,
        startup: config.pterodactyl.defaultStartup,
        environment: config.pterodactyl.defaultEnv,
        limits: {
          memory: plan.ram,
          swap: 0,
          disk: plan.disk,
          io: 500,
          cpu: plan.cpu,
        },
        feature_limits: { databases: 1, backups: 1, allocations: 1 },
        allocation: { default: found.allocation.attributes.id },
      };

      const result = await ptero.createServer(payload);
      const created = result?.attributes;
      if (!created) throw new Error('Panel returned no server');

      servers.record(
        interaction.user.id,
        created.id,
        created.identifier,
        plan.plan_key,
      );
      purchases.attachServer(pendingPurchase.id, created.id);

      await interaction.editReply({
        embeds: [
          embeds.success(
            'Server deployed!',
            `**${created.name}** has been provisioned.\n\n` +
              `🆔 **ID:** \`${created.identifier}\`\n` +
              `🌐 **Panel:** ${config.pterodactyl.panelUrl}/server/${created.identifier}\n\n` +
              'Use `/server-status`, `/server-start`, `/server-stop`, or `/server-restart` to manage it.',
          ),
        ],
      });
    } catch (err) {
      logger.error({ err: err.message, stack: err.stack }, 'failed to provision server');
      await interaction.editReply({
        embeds: [embeds.error('Provisioning failed', describePteroError(err))],
      });
    }
  },
};
