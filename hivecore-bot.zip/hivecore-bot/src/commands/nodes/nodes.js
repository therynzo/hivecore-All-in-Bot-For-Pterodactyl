'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { buildNodeStatusEmbed } = require('../../tasks/nodeStatus');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('nodes').setDescription('Show all Pterodactyl node statuses'),
  async execute(interaction) {
    await interaction.deferReply();
    try {
      const embed = await buildNodeStatusEmbed();
      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      await interaction.editReply({
        embeds: [embeds.error('Failed to load nodes', err.message)],
      });
    }
  },
};
