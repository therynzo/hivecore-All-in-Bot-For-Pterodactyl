'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../../api/pterodactyl');
const { describePteroError } = require('../../api/errors');
const panelAccounts = require('../../database/panelAccounts');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');
const { randomString, randomPassword } = require('../../utils/helpers');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('genaccount')
    .setDescription('Generate your Pterodactyl panel account (credentials sent via DM)'),
  async execute(interaction) {
    const existing = panelAccounts.getByDiscord(interaction.user.id);
    if (existing) {
      await interaction.reply({
        embeds: [
          embeds.warn(
            'Account already exists',
            `You already have a panel account at \`${existing.email}\`. Contact an admin if you need a reset.`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    const username = `u${interaction.user.id.slice(-8)}${randomString(4)}`;
    const localPart = `${randomString(8)}`;
    const email = `${localPart}@${config.account.emailDomain}`;
    const password = randomPassword(16);

    try {
      const exists = await ptero.findUserByEmail(email);
      if (exists) {
        // Extremely unlikely with random local-part, but bail safely.
        throw new Error('Generated email collided; please retry.');
      }

      const result = await ptero.createUser({
        email,
        username,
        firstName: interaction.user.username.slice(0, 30) || 'HiveCore',
        lastName: 'User',
        password,
        rootAdmin: config.account.defaultRole === 'admin',
      });
      const panelUserId = result?.attributes?.id;
      if (!panelUserId) throw new Error('Panel returned no user ID');

      panelAccounts.create(interaction.user.id, panelUserId, email, username);

      try {
        await interaction.user.send({
          embeds: [
            embeds
              .brand('🔐 HiveCore Panel Credentials')
              .setDescription('Keep these safe — do **not** share them.')
              .addFields(
                { name: '🌐 Panel URL', value: config.pterodactyl.panelUrl || 'Not configured' },
                { name: '📧 Email', value: `\`${email}\`` },
                { name: '👤 Username', value: `\`${username}\`` },
                { name: '🔑 Password', value: `\`${password}\`` },
              ),
          ],
        });
      } catch (err) {
        logger.warn({ err: err.message, user: interaction.user.id }, 'failed to DM credentials');
        await interaction.editReply({
          embeds: [
            embeds.warn(
              'DMs disabled',
              `Account created, but I could not DM you. Please **enable DMs** and run \`/recover-credentials\` (admin) for a reset.`,
            ),
          ],
        });
        return;
      }

      await interaction.editReply({
        embeds: [
          embeds.success('Account created!', 'Check your DMs for the panel credentials.'),
        ],
      });
    } catch (err) {
      logger.error({ err: err.message, stack: err.stack }, 'failed to generate panel account');
      await interaction.editReply({
        embeds: [embeds.error('Account generation failed', describePteroError(err))],
      });
    }
  },
};
