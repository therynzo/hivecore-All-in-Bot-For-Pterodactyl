'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../../api/pterodactyl');
const { describePteroError } = require('../../api/errors');
const userKeys = require('../../database/userKeys');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('link')
    .setDescription('Link your personal Pterodactyl client API key (private)')
    .addStringOption((o) =>
      o.setName('api_key').setDescription('Client API key (ptlc_...)').setRequired(true),
    ),
  async execute(interaction) {
    const key = interaction.options.getString('api_key').trim();

    if (!/^ptlc_/.test(key) && !/^[A-Za-z0-9_-]{20,}$/.test(key)) {
      await interaction.reply({
        embeds: [embeds.error('Invalid key', 'Provide a valid Pterodactyl client API key.')],
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });
    try {
      await ptero.validateClientKey(key);
    } catch (err) {
      await interaction.editReply({
        embeds: [embeds.error('Validation failed', describePteroError(err))],
      });
      return;
    }

    userKeys.setKey(interaction.user.id, key);
    await interaction.editReply({
      embeds: [embeds.success('Linked', 'Your client API key is stored. Use `/unlink` to remove it.')],
    });
  },
};
