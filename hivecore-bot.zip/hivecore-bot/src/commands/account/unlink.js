'use strict';

const { SlashCommandBuilder } = require('discord.js');
const userKeys = require('../../database/userKeys');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlink')
    .setDescription('Remove your stored Pterodactyl client API key'),
  async execute(interaction) {
    userKeys.deleteKey(interaction.user.id);
    await interaction.reply({
      embeds: [embeds.success('Unlinked', 'Your client API key has been removed.')],
      ephemeral: true,
    });
  },
};
