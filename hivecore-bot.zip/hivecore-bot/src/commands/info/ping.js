'use strict';

const { SlashCommandBuilder } = require('discord.js');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Bot latency and gateway status'),
  async execute(interaction, client) {
    const sent = await interaction.reply({
      embeds: [embeds.brand('🏓 Pong!').setDescription('Measuring…')],
      fetchReply: true,
    });
    const rtt = sent.createdTimestamp - interaction.createdTimestamp;
    await interaction.editReply({
      embeds: [
        embeds.brand('🏓 Pong!').addFields(
          { name: 'Round-trip', value: `${rtt} ms`, inline: true },
          { name: 'WebSocket', value: `${Math.round(client.ws.ping)} ms`, inline: true },
        ),
      ],
    });
  },
};
