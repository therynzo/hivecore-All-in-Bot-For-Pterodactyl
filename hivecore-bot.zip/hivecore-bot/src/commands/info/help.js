'use strict';

const { SlashCommandBuilder } = require('discord.js');
const embeds = require('../../utils/embeds');

const HELP_SECTIONS = [
  {
    title: '🪙 Economy',
    lines: [
      '`/balance [user]` — Wallet + bank balance',
      '`/daily` — Claim daily reward (7-day streak)',
      '`/work` — Work for coins (30 min cooldown)',
      '`/give @user amount` — Send coins to another user',
      '`/leaderboard` — Top 10 richest users',
      '`/stats` — Server economy overview',
      '`/profile [user]` — Full HiveCore profile',
    ],
  },
  {
    title: '🏦 Bank',
    lines: [
      '`/bank` — View bank info & fee rates',
      '`/deposit amount` — Store coins safely',
      '`/withdraw amount` — Move coins to wallet',
    ],
  },
  {
    title: '🎲 Games',
    lines: [
      '`/coinflip amount side` — 50/50 flip',
      '`/dice guess amount` — Guess the dice (5x)',
      '`/slots amount` — Spin the slots',
      '`/duel @user bet` — Challenge to a duel',
      '`/rob @user` — Steal wallet coins',
      '`/spin` — Daily prize wheel',
    ],
  },
  {
    title: '🛒 Server Shop',
    lines: [
      '`/shop` — Browse Minecraft server plans',
      '`/buy plan:<plan>` — Purchase a plan',
      '`/createserver plan:<plan>` — Deploy after buying',
      '`/genaccount` — Generate panel account (DM)',
      '`/link api_key` — Link your client API key',
      '`/unlink` — Remove your client API key',
    ],
  },
  {
    title: '🛠️ Server Management',
    lines: [
      '`/server-status` — Status + resource usage',
      '`/server-start` / `/server-stop` / `/server-restart` / `/server-kill`',
      '`/server-console` — Recent console logs',
      '`/manage` — Button-based control panel',
    ],
  },
  {
    title: '📡 Nodes',
    lines: ['`/nodes` — Show all node statuses (auto-refreshes every 3 min in the configured channel)'],
  },
  {
    title: '🚫 Admin Only',
    lines: [
      '`/setcoins @user amount` — Set wallet balance',
      '`/addcoins @user amount` — Add (or subtract) coins',
      '`/reset @user` — Reset coins to 0',
      '`/drop amount` — Coin drop (first to claim)',
      '`/setchannel type channel` — Configure log/status channels',
      '`/plan add|remove|toggle|list` — Manage shop plans',
      '`/admin-deleteserver @user` — Remove a server from the panel',
    ],
  },
];

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Show all HiveCore commands'),
  async execute(interaction) {
    const embed = embeds
      .brand('📖 HiveCore Coins — Command Guide')
      .setDescription('Everything you need to earn, spend, and grow your HiveCore Coins!');
    for (const section of HELP_SECTIONS) {
      embed.addFields({ name: section.title, value: section.lines.join('\n'), inline: false });
    }
    await interaction.reply({ embeds: [embed] });
  },
};
