'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');
const { randomInt } = require('../../utils/helpers');
const { formatDuration } = require('../../utils/cooldowns');

const ONE_DAY = 24 * 60 * 60 * 1000;
const TWO_DAYS = 2 * ONE_DAY;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily reward (7-day streak bonus)'),
  async execute(interaction) {
    const u = users.getUser(interaction.user.id);
    const now = Date.now();
    const elapsed = now - (u.last_daily || 0);

    if (elapsed < ONE_DAY) {
      const remaining = ONE_DAY - elapsed;
      await interaction.reply({
        embeds: [
          embeds.warn(
            'Already claimed',
            `You can claim your next daily reward in **${formatDuration(remaining)}**.`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    let streak = u.daily_streak || 0;
    if (elapsed > TWO_DAYS) {
      streak = 1;
    } else {
      streak = Math.min(streak + 1, 7);
    }

    const base = randomInt(config.economy.dailyMin, config.economy.dailyMax);
    const bonus = streak >= 7 ? Math.floor(base * 0.5) : 0;
    const total = base + bonus;

    users.addCoins(interaction.user.id, total);
    users.recordDaily(interaction.user.id, streak);

    const embed = embeds
      .brand('☀️ Daily Reward Claimed')
      .setDescription(
        `You received ${embeds.formatCoins(total)}` +
          (bonus ? `\n🎉 **7-day streak bonus:** +${embeds.formatCoins(bonus)}` : ''),
      )
      .addFields({ name: '🔥 Streak', value: `${streak} / 7`, inline: true });
    await interaction.reply({ embeds: [embed] });
  },
};
