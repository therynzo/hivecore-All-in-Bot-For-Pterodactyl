'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('give')
    .setDescription('Send coins from your wallet to another user')
    .addUserOption((o) => o.setName('user').setDescription('Recipient').setRequired(true))
    .addIntegerOption((o) =>
      o.setName('amount').setDescription('How many coins to send').setRequired(true).setMinValue(1),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    if (target.bot) {
      await interaction.reply({ embeds: [embeds.error('Invalid user', 'You cannot send coins to a bot.')], ephemeral: true });
      return;
    }
    if (target.id === interaction.user.id) {
      await interaction.reply({ embeds: [embeds.error('Invalid user', 'You cannot send coins to yourself.')], ephemeral: true });
      return;
    }

    const sender = users.getUser(interaction.user.id);
    if (sender.wallet < amount) {
      await interaction.reply({
        embeds: [
          embeds.error(
            'Insufficient funds',
            `You only have ${embeds.formatCoins(sender.wallet)} in your wallet.`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    users.addCoins(interaction.user.id, -amount);
    users.addCoins(target.id, amount);

    await interaction.reply({
      embeds: [
        embeds
          .success(
            'Transfer complete',
            `${interaction.user} sent ${embeds.formatCoins(amount)} to ${target}.`,
          ),
      ],
    });
  },
};
