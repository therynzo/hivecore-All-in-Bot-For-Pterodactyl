'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your wallet and bank balance')
    .addUserOption((opt) =>
      opt.setName('user').setDescription('User to check balance for').setRequired(false),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const u = users.getUser(target.id);
    const total = u.wallet + u.bank;
    const embed = embeds
      .brand(`${config.branding.coinEmoji} ${target.username}'s Wallet`)
      .addFields(
        { name: '👛 Wallet', value: embeds.formatCoins(u.wallet), inline: true },
        { name: '🏦 Bank', value: embeds.formatCoins(u.bank), inline: true },
        { name: '📊 Total', value: embeds.formatCoins(total), inline: true },
      )
      .setThumbnail(target.displayAvatarURL());
    await interaction.reply({ embeds: [embed] });
  },
};
