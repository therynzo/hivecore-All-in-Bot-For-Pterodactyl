'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const panelAccounts = require('../../database/panelAccounts');
const servers = require('../../database/servers');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription("View your or another user's full HiveCore profile")
    .addUserOption((o) => o.setName('user').setDescription('User').setRequired(false)),
  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const u = users.getUser(target.id);
    const account = panelAccounts.getByDiscord(target.id);
    const owned = servers.listForUser(target.id);

    const embed = embeds
      .brand(`⭐ ${target.username}'s Profile`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: '👛 Wallet', value: embeds.formatCoins(u.wallet), inline: true },
        { name: '🏦 Bank', value: embeds.formatCoins(u.bank), inline: true },
        { name: '🔥 Daily Streak', value: `${u.daily_streak} / 7`, inline: true },
        {
          name: '📡 Panel Account',
          value: account ? `\`${account.email}\`` : 'Not generated',
          inline: false,
        },
        {
          name: '🖥️ Servers Owned',
          value: owned.length ? `${owned.length} server(s)` : 'None',
          inline: true,
        },
      )
      .setFooter({ text: `${config.branding.footer} • ${target.tag}` });
    await interaction.reply({ embeds: [embed] });
  },
};
