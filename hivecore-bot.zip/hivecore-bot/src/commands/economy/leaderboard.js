'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');

const MEDALS = ['🥇', '🥈', '🥉'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Top 10 richest users (wallet + bank)'),
  async execute(interaction, client) {
    const top = users.getTopUsers(10);
    if (top.length === 0) {
      await interaction.reply({
        embeds: [embeds.info('Leaderboard', 'No users with coins yet.')],
      });
      return;
    }

    const lines = await Promise.all(
      top.map(async (row, idx) => {
        const medal = MEDALS[idx] || `\`#${idx + 1}\``;
        let username = row.discord_id;
        try {
          const user = await client.users.fetch(row.discord_id);
          username = user.username;
        } catch {
          // ignore unknown user; show ID instead.
        }
        return `${medal} **${username}** — ${embeds.formatCoins(row.total)}`;
      }),
    );

    await interaction.reply({
      embeds: [embeds.brand('🏆 HiveCore Leaderboard').setDescription(lines.join('\n'))],
    });
  },
};
