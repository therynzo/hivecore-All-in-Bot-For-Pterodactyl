'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');
const { randomInt, randomElement } = require('../../utils/helpers');
const { formatDuration } = require('../../utils/cooldowns');

const JOBS = [
  'You patched a node and earned',
  'You provisioned a Minecraft server and earned',
  'You debugged a startup script and earned',
  'You optimised disk I/O and earned',
  'You handled a support ticket and earned',
  'You renewed an SSL cert and earned',
  'You upgraded a panel theme and earned',
];

module.exports = {
  data: new SlashCommandBuilder().setName('work').setDescription('Work a job for coins (30 min cooldown)'),
  async execute(interaction) {
    const u = users.getUser(interaction.user.id);
    const cooldown = config.economy.workCooldownMin * 60 * 1000;
    const elapsed = Date.now() - (u.last_work || 0);
    if (elapsed < cooldown) {
      await interaction.reply({
        embeds: [
          embeds.warn(
            'Slow down!',
            `You can work again in **${formatDuration(cooldown - elapsed)}**.`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    const earned = randomInt(config.economy.workMin, config.economy.workMax);
    users.addCoins(interaction.user.id, earned);
    users.recordWork(interaction.user.id);

    await interaction.reply({
      embeds: [
        embeds
          .brand('💼 Work Complete')
          .setDescription(`${randomElement(JOBS)} ${embeds.formatCoins(earned)}`),
      ],
    });
  },
};
