'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('stats').setDescription('Server economy overview'),
  async execute(interaction) {
    const stats = users.getStats();
    const total = stats.walletTotal + stats.bankTotal;
    await interaction.reply({
      embeds: [
        embeds
          .brand('📊 Server Economy')
          .addFields(
            { name: '👥 Tracked users', value: String(stats.users), inline: true },
            { name: '👛 Total in wallets', value: embeds.formatCoins(stats.walletTotal), inline: true },
            { name: '🏦 Total in banks', value: embeds.formatCoins(stats.bankTotal), inline: true },
            { name: '💰 Total in circulation', value: embeds.formatCoins(total), inline: false },
          ),
      ],
    });
  },
};
