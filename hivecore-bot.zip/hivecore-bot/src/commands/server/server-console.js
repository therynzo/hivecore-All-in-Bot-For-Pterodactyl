'use strict';

const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const ptero = require('../../api/pterodactyl');
const { describePteroError } = require('../../api/errors');
const servers = require('../../database/servers');
const userKeys = require('../../database/userKeys');
const embeds = require('../../utils/embeds');
const { truncate } = require('../../utils/helpers');
const { config } = require('../../config/config');

function resolveKey(discordId) {
  return userKeys.getKey(discordId)?.api_key || config.pterodactyl.clientKey;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('server-console')
    .setDescription('Show recent console logs for your server')
    .addIntegerOption((o) =>
      o.setName('lines').setDescription('How many recent lines (default 30)').setMinValue(5).setMaxValue(200),
    ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const lineCount = interaction.options.getInteger('lines') || 30;
    const owned = servers.firstForUser(interaction.user.id);
    if (!owned) {
      await interaction.editReply({
        embeds: [embeds.error('No server', 'You don\'t own a server.')],
      });
      return;
    }
    try {
      const raw = await ptero.getRecentLogs(owned.identifier, resolveKey(interaction.user.id));
      if (!raw || raw.length === 0) {
        await interaction.editReply({
          embeds: [embeds.warn('No logs', 'No log file is available yet — start the server first.')],
        });
        return;
      }
      const tail = raw.split('\n').filter(Boolean).slice(-lineCount).join('\n');
      const block = `\`\`\`\n${truncate(tail, 1800)}\n\`\`\``;

      // If the trimmed log fits, send it in an embed; otherwise attach a file.
      if (tail.length <= 1800) {
        await interaction.editReply({
          embeds: [embeds.brand('🖥️ Server Console (recent)').setDescription(block)],
        });
      } else {
        const file = new AttachmentBuilder(Buffer.from(tail, 'utf8'), { name: 'console.log' });
        await interaction.editReply({
          embeds: [embeds.brand('🖥️ Server Console').setDescription('Log too long — attached as file.')],
          files: [file],
        });
      }
    } catch (err) {
      await interaction.editReply({
        embeds: [embeds.error('Failed to fetch logs', describePteroError(err))],
      });
    }
  },
};
