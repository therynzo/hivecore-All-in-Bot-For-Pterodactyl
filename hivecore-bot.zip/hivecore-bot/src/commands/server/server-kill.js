'use strict';

module.exports = require('./server-power').kill;
