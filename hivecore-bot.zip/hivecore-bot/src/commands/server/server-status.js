'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../../api/pterodactyl');
const { describePteroError } = require('../../api/errors');
const servers = require('../../database/servers');
const userKeys = require('../../database/userKeys');
const embeds = require('../../utils/embeds');
const { bytesToMB, progressBar } = require('../../utils/helpers');
const { config } = require('../../config/config');

function resolveKey(discordId) {
  return userKeys.getKey(discordId)?.api_key || config.pterodactyl.clientKey;
}

const STATE_ICONS = {
  running: '🟢',
  starting: '🟡',
  stopping: '🟠',
  offline: '🔴',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('server-status')
    .setDescription('Show your server status and resource usage')
    .addStringOption((o) =>
      o.setName('identifier').setDescription('Server identifier (optional)').setRequired(false),
    ),
  async execute(interaction) {
    await interaction.deferReply();
    const identifier = interaction.options.getString('identifier');
    const owned = identifier
      ? servers.findForUser(interaction.user.id, identifier)
      : servers.firstForUser(interaction.user.id);
    if (!owned) {
      await interaction.editReply({
        embeds: [embeds.error('No server', 'Buy and deploy a server first using `/shop` and `/createserver`.')],
      });
      return;
    }

    try {
      const key = resolveKey(interaction.user.id);
      const [details, resources] = await Promise.all([
        ptero.getClientServer(owned.identifier, key),
        ptero.getServerResources(owned.identifier, key),
      ]);
      const a = details.attributes;
      const r = resources.attributes;
      const state = r.current_state || 'unknown';
      const ramUsed = bytesToMB(r.resources?.memory_bytes || 0);
      const ramMax = a.limits?.memory || 0;
      const ramPct = ramMax ? Math.min(100, (ramUsed / ramMax) * 100) : 0;
      const cpuPct = Math.min(100, r.resources?.cpu_absolute || 0);
      const diskUsed = bytesToMB(r.resources?.disk_bytes || 0);
      const diskMax = a.limits?.disk || 0;
      const diskPct = diskMax ? Math.min(100, (diskUsed / diskMax) * 100) : 0;

      const embed = embeds
        .brand(`${STATE_ICONS[state] || '⚪'} ${a.name}`)
        .setDescription(`Identifier: \`${a.identifier}\``)
        .addFields(
          { name: '📡 State', value: `${STATE_ICONS[state] || '⚪'} ${state}`, inline: true },
          {
            name: '⚙️ CPU',
            value: `${progressBar(cpuPct)} ${cpuPct.toFixed(1)}%`,
            inline: true,
          },
          {
            name: '🧠 RAM',
            value: `${progressBar(ramPct)} ${ramUsed.toFixed(0)} / ${ramMax} MB`,
            inline: true,
          },
          {
            name: '💽 Disk',
            value: `${progressBar(diskPct)} ${diskUsed.toFixed(0)} / ${diskMax} MB`,
            inline: true,
          },
          {
            name: '🌐 Panel',
            value: `${config.pterodactyl.panelUrl}/server/${a.identifier}`,
            inline: false,
          },
        );
      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      await interaction.editReply({
        embeds: [embeds.error('Failed to fetch status', describePteroError(err))],
      });
    }
  },
};
