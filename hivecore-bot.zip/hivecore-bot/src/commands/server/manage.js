'use strict';

const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
} = require('discord.js');
const ptero = require('../../api/pterodactyl');
const { describePteroError } = require('../../api/errors');
const servers = require('../../database/servers');
const userKeys = require('../../database/userKeys');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');

function resolveKey(discordId) {
  return userKeys.getKey(discordId)?.api_key || config.pterodactyl.clientKey;
}

function row() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('manage:start').setLabel('Start').setEmoji('▶️').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('manage:stop').setLabel('Stop').setEmoji('⏹️').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('manage:restart').setLabel('Restart').setEmoji('♻️').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('manage:status').setLabel('Status').setEmoji('📊').setStyle(ButtonStyle.Secondary),
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('manage')
    .setDescription('Manage your server (start/stop/restart/status) with buttons'),
  async execute(interaction) {
    const owned = servers.firstForUser(interaction.user.id);
    if (!owned) {
      await interaction.reply({
        embeds: [embeds.error('No server', 'You don\'t own a server.')],
        ephemeral: true,
      });
      return;
    }

    const message = await interaction.reply({
      embeds: [
        embeds
          .brand('🛠️ Server Control Panel')
          .setDescription(`Identifier: \`${owned.identifier}\`\nUse the buttons below to manage your server.`),
      ],
      components: [row()],
      ephemeral: true,
      fetchReply: true,
    });

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 5 * 60 * 1000,
      filter: (i) => i.user.id === interaction.user.id,
    });

    collector.on('collect', async (i) => {
      const action = i.customId.split(':')[1];
      try {
        if (action === 'status') {
          const key = resolveKey(interaction.user.id);
          const res = await ptero.getServerResources(owned.identifier, key);
          await i.update({
            embeds: [
              embeds
                .brand('📊 Status')
                .setDescription(`State: **${res.attributes?.current_state || 'unknown'}**`),
            ],
            components: [row()],
          });
          return;
        }
        await ptero.sendPowerSignal(owned.identifier, action, resolveKey(interaction.user.id));
        await i.update({
          embeds: [
            embeds.success(`Sent ${action}`, `Signal dispatched to \`${owned.identifier}\`.`),
          ],
          components: [row()],
        });
      } catch (err) {
        await i.update({
          embeds: [embeds.error(`Failed to ${action}`, describePteroError(err))],
          components: [row()],
        });
      }
    });
  },
};

module.exports.config = config;
