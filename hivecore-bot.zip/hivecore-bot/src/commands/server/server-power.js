'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../../api/pterodactyl');
const { describePteroError } = require('../../api/errors');
const servers = require('../../database/servers');
const userKeys = require('../../database/userKeys');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');

function resolveKey(discordId) {
  return userKeys.getKey(discordId)?.api_key || config.pterodactyl.clientKey;
}

function buildCommand(name, signal, description) {
  return {
    data: new SlashCommandBuilder()
      .setName(name)
      .setDescription(description)
      .addStringOption((o) =>
        o.setName('identifier').setDescription('Server identifier (optional)').setRequired(false),
      ),
    async execute(interaction) {
      await interaction.deferReply();
      const identifier = interaction.options.getString('identifier');
      const owned = identifier
        ? servers.findForUser(interaction.user.id, identifier)
        : servers.firstForUser(interaction.user.id);
      if (!owned) {
        await interaction.editReply({
          embeds: [embeds.error('No server', 'You don\'t own a server.')],
        });
        return;
      }
      try {
        await ptero.sendPowerSignal(owned.identifier, signal, resolveKey(interaction.user.id));
        await interaction.editReply({
          embeds: [
            embeds.success(
              `Sent ${signal} signal`,
              `Server \`${owned.identifier}\` will ${signal} shortly.`,
            ),
          ],
        });
      } catch (err) {
        await interaction.editReply({
          embeds: [embeds.error(`Failed to ${signal}`, describePteroError(err))],
        });
      }
    },
  };
}

module.exports = buildCommand('server-restart', 'restart', 'Restart your server');
module.exports.start = buildCommand('server-start', 'start', 'Start your server');
module.exports.stop = buildCommand('server-stop', 'stop', 'Stop your server');
module.exports.kill = buildCommand('server-kill', 'kill', 'Force-kill your server');
