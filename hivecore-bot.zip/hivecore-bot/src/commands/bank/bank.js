'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bank')
    .setDescription('View your bank info & fee rates'),
  async execute(interaction) {
    const u = users.getUser(interaction.user.id);
    const embed = embeds
      .brand('🏦 HiveCore Bank')
      .setDescription('Store coins safely — bank coins **cannot** be robbed!')
      .addFields(
        { name: '👛 Wallet', value: embeds.formatCoins(u.wallet), inline: true },
        { name: '🏦 Bank', value: embeds.formatCoins(u.bank), inline: true },
        {
          name: '📦 Bank Limit',
          value: `${config.economy.bankLimit.toLocaleString('en-US')} ${config.branding.coinSymbol}`,
          inline: true,
        },
        {
          name: '📥 Deposit Fee',
          value: `${(config.economy.bankDepositFee * 100).toFixed(0)}%`,
          inline: true,
        },
        {
          name: '📤 Withdraw Fee',
          value: `${(config.economy.bankWithdrawFee * 100).toFixed(0)}%`,
          inline: true,
        },
      );
    await interaction.reply({ embeds: [embed] });
  },
};
