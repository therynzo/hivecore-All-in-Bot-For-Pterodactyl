'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('deposit')
    .setDescription('Store coins safely in your bank (deposit fee applies)')
    .addStringOption((o) =>
      o.setName('amount').setDescription('Amount of coins or "all"').setRequired(true),
    ),
  async execute(interaction) {
    const raw = interaction.options.getString('amount').trim().toLowerCase();
    const u = users.getUser(interaction.user.id);

    let amount;
    if (raw === 'all') amount = u.wallet;
    else amount = parseInt(raw, 10);

    if (!Number.isFinite(amount) || amount <= 0) {
      await interaction.reply({
        embeds: [embeds.error('Invalid amount', 'Provide a positive integer or `all`.')],
        ephemeral: true,
      });
      return;
    }
    if (amount > u.wallet) {
      await interaction.reply({
        embeds: [
          embeds.error(
            'Insufficient funds',
            `You only have ${embeds.formatCoins(u.wallet)} in your wallet.`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    const fee = Math.floor(amount * config.economy.bankDepositFee);
    const netDeposit = amount - fee;
    const newBank = u.bank + netDeposit;
    if (newBank > config.economy.bankLimit) {
      const allowed = config.economy.bankLimit - u.bank;
      await interaction.reply({
        embeds: [
          embeds.error(
            'Bank limit reached',
            `Your bank limit is **${config.economy.bankLimit.toLocaleString('en-US')}** ${config.branding.coinSymbol}. You can deposit at most ${allowed.toLocaleString('en-US')} more (after fees).`,
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    users.addCoins(interaction.user.id, -amount);
    users.addBank(interaction.user.id, netDeposit);

    await interaction.reply({
      embeds: [
        embeds
          .success(
            'Deposit complete',
            `Deposited ${embeds.formatCoins(netDeposit)} (fee: ${embeds.formatCoins(fee)})`,
          ),
      ],
    });
  },
};
