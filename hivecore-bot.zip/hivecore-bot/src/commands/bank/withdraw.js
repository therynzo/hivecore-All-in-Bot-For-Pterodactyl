'use strict';

const { SlashCommandBuilder } = require('discord.js');
const users = require('../../database/users');
const embeds = require('../../utils/embeds');
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('withdraw')
    .setDescription('Move coins from bank to wallet (withdraw fee applies)')
    .addStringOption((o) =>
      o.setName('amount').setDescription('Amount of coins or "all"').setRequired(true),
    ),
  async execute(interaction) {
    const raw = interaction.options.getString('amount').trim().toLowerCase();
    const u = users.getUser(interaction.user.id);

    let amount;
    if (raw === 'all') amount = u.bank;
    else amount = parseInt(raw, 10);

    if (!Number.isFinite(amount) || amount <= 0) {
      await interaction.reply({
        embeds: [embeds.error('Invalid amount', 'Provide a positive integer or `all`.')],
        ephemeral: true,
      });
      return;
    }
    if (amount > u.bank) {
      await interaction.reply({
        embeds: [
          embeds.error('Insufficient bank balance', `You only have ${embeds.formatCoins(u.bank)} in your bank.`),
        ],
        ephemeral: true,
      });
      return;
    }

    const fee = Math.floor(amount * config.economy.bankWithdrawFee);
    const netWithdraw = amount - fee;
    users.addBank(interaction.user.id, -amount);
    users.addCoins(interaction.user.id, netWithdraw);

    await interaction.reply({
      embeds: [
        embeds
          .success(
            'Withdrawal complete',
            `Withdrew ${embeds.formatCoins(netWithdraw)} (fee: ${embeds.formatCoins(fee)})`,
          ),
      ],
    });
  },
};
