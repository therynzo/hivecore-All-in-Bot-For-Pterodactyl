'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const { config } = require('../config/config');
const logger = require('../utils/logger');

const dbPath = path.isAbsolute(config.database.path)
  ? config.database.path
  : path.resolve(process.cwd(), config.database.path);

fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS users (
    discord_id TEXT PRIMARY KEY,
    wallet INTEGER NOT NULL DEFAULT 0,
    bank INTEGER NOT NULL DEFAULT 0,
    last_daily INTEGER NOT NULL DEFAULT 0,
    daily_streak INTEGER NOT NULL DEFAULT 0,
    last_work INTEGER NOT NULL DEFAULT 0,
    last_rob INTEGER NOT NULL DEFAULT 0,
    last_spin INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS panel_accounts (
    discord_id TEXT PRIMARY KEY,
    panel_user_id INTEGER NOT NULL,
    email TEXT NOT NULL,
    username TEXT NOT NULL,
    created_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS user_keys (
    discord_id TEXT PRIMARY KEY,
    api_key TEXT NOT NULL,
    created_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS owned_servers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id TEXT NOT NULL,
    panel_server_id INTEGER NOT NULL,
    identifier TEXT NOT NULL,
    plan_key TEXT,
    created_at INTEGER NOT NULL,
    UNIQUE(discord_id, panel_server_id)
  )`,
  `CREATE TABLE IF NOT EXISTS shop_plans (
    plan_key TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    emoji TEXT NOT NULL DEFAULT '🌱',
    price INTEGER NOT NULL,
    ram INTEGER NOT NULL,
    cpu INTEGER NOT NULL,
    disk INTEGER NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS bot_config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id TEXT NOT NULL,
    plan_key TEXT NOT NULL,
    price INTEGER NOT NULL,
    panel_server_id INTEGER,
    created_at INTEGER NOT NULL
  )`,
];

for (const stmt of SCHEMA) {
  db.exec(stmt);
}

logger.info({ path: dbPath }, 'database initialized');

module.exports = db;
