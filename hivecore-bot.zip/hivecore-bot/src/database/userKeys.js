'use strict';

const db = require('./db');

const upsert = db.prepare(`
  INSERT INTO user_keys (discord_id, api_key, created_at)
  VALUES (?, ?, ?)
  ON CONFLICT(discord_id) DO UPDATE SET api_key = excluded.api_key, created_at = excluded.created_at
`);
const selectOne = db.prepare('SELECT * FROM user_keys WHERE discord_id = ?');
const deleteOne = db.prepare('DELETE FROM user_keys WHERE discord_id = ?');

function setKey(discordId, apiKey) {
  upsert.run(discordId, apiKey, Date.now());
}

function getKey(discordId) {
  return selectOne.get(discordId);
}

function deleteKey(discordId) {
  deleteOne.run(discordId);
}

module.exports = { setKey, getKey, deleteKey };
