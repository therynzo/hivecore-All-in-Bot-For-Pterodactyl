'use strict';

const db = require('./db');

const insert = db.prepare(`
  INSERT INTO panel_accounts (discord_id, panel_user_id, email, username, created_at)
  VALUES (?, ?, ?, ?, ?)
`);
const selectByDiscord = db.prepare('SELECT * FROM panel_accounts WHERE discord_id = ?');
const deleteByDiscord = db.prepare('DELETE FROM panel_accounts WHERE discord_id = ?');

function getByDiscord(discordId) {
  return selectByDiscord.get(discordId);
}

function create(discordId, panelUserId, email, username) {
  insert.run(discordId, panelUserId, email, username, Date.now());
}

function remove(discordId) {
  deleteByDiscord.run(discordId);
}

module.exports = { getByDiscord, create, remove };
