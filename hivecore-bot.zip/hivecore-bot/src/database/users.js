'use strict';

const db = require('./db');

const insert = db.prepare(`
  INSERT INTO users (discord_id, wallet, bank, last_daily, daily_streak, last_work, last_rob, last_spin, created_at, updated_at)
  VALUES (@discord_id, 0, 0, 0, 0, 0, 0, 0, @now, @now)
`);
const selectOne = db.prepare('SELECT * FROM users WHERE discord_id = ?');
const updateWallet = db.prepare(
  'UPDATE users SET wallet = wallet + ?, updated_at = ? WHERE discord_id = ?',
);
const setWallet = db.prepare(
  'UPDATE users SET wallet = ?, updated_at = ? WHERE discord_id = ?',
);
const updateBank = db.prepare(
  'UPDATE users SET bank = bank + ?, updated_at = ? WHERE discord_id = ?',
);
const setBank = db.prepare(
  'UPDATE users SET bank = ?, updated_at = ? WHERE discord_id = ?',
);
const setDaily = db.prepare(
  'UPDATE users SET last_daily = ?, daily_streak = ?, updated_at = ? WHERE discord_id = ?',
);
const setLastWork = db.prepare(
  'UPDATE users SET last_work = ?, updated_at = ? WHERE discord_id = ?',
);
const setLastRob = db.prepare(
  'UPDATE users SET last_rob = ?, updated_at = ? WHERE discord_id = ?',
);
const setLastSpin = db.prepare(
  'UPDATE users SET last_spin = ?, updated_at = ? WHERE discord_id = ?',
);
const topByTotal = db.prepare(
  'SELECT discord_id, wallet, bank, (wallet + bank) AS total FROM users ORDER BY total DESC LIMIT ?',
);
const countAll = db.prepare('SELECT COUNT(*) AS c FROM users');
const sumAll = db.prepare(
  'SELECT IFNULL(SUM(wallet), 0) AS total_wallet, IFNULL(SUM(bank), 0) AS total_bank FROM users',
);

function ensureUser(discordId) {
  let row = selectOne.get(discordId);
  if (!row) {
    insert.run({ discord_id: discordId, now: Date.now() });
    row = selectOne.get(discordId);
  }
  return row;
}

function getUser(discordId) {
  return ensureUser(discordId);
}

function addCoins(discordId, amount) {
  ensureUser(discordId);
  updateWallet.run(amount, Date.now(), discordId);
}

function setCoins(discordId, amount) {
  ensureUser(discordId);
  setWallet.run(amount, Date.now(), discordId);
}

function addBank(discordId, amount) {
  ensureUser(discordId);
  updateBank.run(amount, Date.now(), discordId);
}

function setBankCoins(discordId, amount) {
  ensureUser(discordId);
  setBank.run(amount, Date.now(), discordId);
}

function recordDaily(discordId, streak) {
  ensureUser(discordId);
  setDaily.run(Date.now(), streak, Date.now(), discordId);
}

function recordWork(discordId) {
  ensureUser(discordId);
  setLastWork.run(Date.now(), Date.now(), discordId);
}

function recordRob(discordId) {
  ensureUser(discordId);
  setLastRob.run(Date.now(), Date.now(), discordId);
}

function recordSpin(discordId) {
  ensureUser(discordId);
  setLastSpin.run(Date.now(), Date.now(), discordId);
}

function getTopUsers(limit = 10) {
  return topByTotal.all(limit);
}

function getStats() {
  const counts = countAll.get();
  const sums = sumAll.get();
  return {
    users: counts.c,
    walletTotal: sums.total_wallet,
    bankTotal: sums.total_bank,
  };
}

module.exports = {
  ensureUser,
  getUser,
  addCoins,
  setCoins,
  addBank,
  setBankCoins,
  recordDaily,
  recordWork,
  recordRob,
  recordSpin,
  getTopUsers,
  getStats,
};
