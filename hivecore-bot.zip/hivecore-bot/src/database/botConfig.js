'use strict';

const db = require('./db');

const upsert = db.prepare(`
  INSERT INTO bot_config (key, value, updated_at) VALUES (?, ?, ?)
  ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`);
const selectOne = db.prepare('SELECT value FROM bot_config WHERE key = ?');
const deleteOne = db.prepare('DELETE FROM bot_config WHERE key = ?');

function set(key, value) {
  upsert.run(key, String(value), Date.now());
}

function get(key, fallback = null) {
  const row = selectOne.get(key);
  return row ? row.value : fallback;
}

function remove(key) {
  deleteOne.run(key);
}

module.exports = { set, get, remove };
