'use strict';

const db = require('./db');

const insert = db.prepare(`
  INSERT INTO purchases (discord_id, plan_key, price, panel_server_id, created_at)
  VALUES (?, ?, ?, ?, ?)
`);
const updateServer = db.prepare(
  'UPDATE purchases SET panel_server_id = ? WHERE id = ?',
);
const selectByDiscord = db.prepare(
  'SELECT * FROM purchases WHERE discord_id = ? ORDER BY created_at DESC',
);

function create(discordId, planKey, price) {
  const result = insert.run(discordId, planKey, price, null, Date.now());
  return Number(result.lastInsertRowid);
}

function attachServer(purchaseId, panelServerId) {
  updateServer.run(panelServerId, purchaseId);
}

function listForUser(discordId) {
  return selectByDiscord.all(discordId);
}

module.exports = { create, attachServer, listForUser };
