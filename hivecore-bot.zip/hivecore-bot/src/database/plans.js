'use strict';

const db = require('./db');

const upsert = db.prepare(`
  INSERT INTO shop_plans (plan_key, name, emoji, price, ram, cpu, disk, enabled, created_at, updated_at)
  VALUES (@plan_key, @name, @emoji, @price, @ram, @cpu, @disk, @enabled, @now, @now)
  ON CONFLICT(plan_key) DO UPDATE SET
    name = excluded.name,
    emoji = excluded.emoji,
    price = excluded.price,
    ram = excluded.ram,
    cpu = excluded.cpu,
    disk = excluded.disk,
    enabled = excluded.enabled,
    updated_at = excluded.updated_at
`);
const insertOnly = db.prepare(`
  INSERT OR IGNORE INTO shop_plans (plan_key, name, emoji, price, ram, cpu, disk, enabled, created_at, updated_at)
  VALUES (@plan_key, @name, @emoji, @price, @ram, @cpu, @disk, @enabled, @now, @now)
`);
const selectOne = db.prepare('SELECT * FROM shop_plans WHERE plan_key = ?');
const selectAll = db.prepare(
  'SELECT * FROM shop_plans ORDER BY price ASC',
);
const selectEnabled = db.prepare(
  'SELECT * FROM shop_plans WHERE enabled = 1 ORDER BY price ASC',
);
const deleteOne = db.prepare('DELETE FROM shop_plans WHERE plan_key = ?');
const setEnabled = db.prepare(
  'UPDATE shop_plans SET enabled = ?, updated_at = ? WHERE plan_key = ?',
);

const DEFAULT_PLANS = [
  { plan_key: 'starter', name: 'Starter Plan', emoji: '🌱', price: 300, ram: 1024, cpu: 100, disk: 10240, enabled: 1 },
  { plan_key: 'basic', name: 'Basic Plan', emoji: '🔷', price: 600, ram: 2048, cpu: 200, disk: 15360, enabled: 1 },
  { plan_key: 'standard', name: 'Standard Plan', emoji: '⭐', price: 1000, ram: 3072, cpu: 300, disk: 20480, enabled: 1 },
  { plan_key: 'premium', name: 'Premium Plan', emoji: '💎', price: 1600, ram: 4096, cpu: 400, disk: 25600, enabled: 1 },
  { plan_key: 'extreme', name: 'Extreme Plan', emoji: '🔥', price: 2200, ram: 6144, cpu: 500, disk: 30720, enabled: 1 },
];

function seedDefaults() {
  const now = Date.now();
  for (const plan of DEFAULT_PLANS) {
    insertOnly.run({ ...plan, now });
  }
}

seedDefaults();

function get(planKey) {
  return selectOne.get(planKey);
}

function listAll() {
  return selectAll.all();
}

function listEnabled() {
  return selectEnabled.all();
}

function save(plan) {
  upsert.run({ ...plan, now: Date.now() });
}

function remove(planKey) {
  deleteOne.run(planKey);
}

function toggle(planKey, enabled) {
  setEnabled.run(enabled ? 1 : 0, Date.now(), planKey);
}

module.exports = { get, listAll, listEnabled, save, remove, toggle, DEFAULT_PLANS };
