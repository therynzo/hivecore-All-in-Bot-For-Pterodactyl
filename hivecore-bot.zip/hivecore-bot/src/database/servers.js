'use strict';

const db = require('./db');

const insert = db.prepare(`
  INSERT INTO owned_servers (discord_id, panel_server_id, identifier, plan_key, created_at)
  VALUES (?, ?, ?, ?, ?)
`);
const selectByDiscord = db.prepare(
  'SELECT * FROM owned_servers WHERE discord_id = ? ORDER BY created_at ASC',
);
const selectFirst = db.prepare(
  'SELECT * FROM owned_servers WHERE discord_id = ? ORDER BY created_at ASC LIMIT 1',
);
const selectByIdentifier = db.prepare(
  'SELECT * FROM owned_servers WHERE discord_id = ? AND identifier = ?',
);
const deleteByPanelId = db.prepare('DELETE FROM owned_servers WHERE panel_server_id = ?');

function record(discordId, panelServerId, identifier, planKey) {
  insert.run(discordId, panelServerId, identifier, planKey || null, Date.now());
}

function listForUser(discordId) {
  return selectByDiscord.all(discordId);
}

function firstForUser(discordId) {
  return selectFirst.get(discordId);
}

function findForUser(discordId, identifier) {
  return selectByIdentifier.get(discordId, identifier);
}

function removeByPanelId(panelServerId) {
  deleteByPanelId.run(panelServerId);
}

module.exports = { record, listForUser, firstForUser, findForUser, removeByPanelId };
