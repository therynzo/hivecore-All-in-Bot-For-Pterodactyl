'use strict';

require('dotenv').config();

function parseList(value) {
  if (!value) return [];
  return value.split(',').map((v) => v.trim()).filter(Boolean);
}

function parseInteger(value, fallback) {
  const n = parseInt(value, 10);
  return Number.isFinite(n) ? n : fallback;
}

function parseFloatValue(value, fallback) {
  const n = parseFloat(value);
  return Number.isFinite(n) ? n : fallback;
}

function parseJSONOrEmpty(value) {
  if (!value) return {};
  try {
    return JSON.parse(value);
  } catch {
    return {};
  }
}

const config = {
  discord: {
    token: process.env.DISCORD_TOKEN || '',
    clientId: process.env.DISCORD_CLIENT_ID || '',
    devGuildIds: parseList(process.env.DISCORD_DEV_GUILD_IDS),
  },
  pterodactyl: {
    panelUrl: (process.env.PTERO_PANEL_URL || '').replace(/\/+$/, ''),
    appKey: process.env.PTERO_APP_API_KEY || '',
    clientKey: process.env.PTERO_CLIENT_API_KEY || '',
    defaultEggId: parseInteger(process.env.PTERO_DEFAULT_EGG_ID, 1),
    defaultNestId: parseInteger(process.env.PTERO_DEFAULT_NEST_ID, 1),
    defaultLocationId: parseInteger(process.env.PTERO_DEFAULT_LOCATION_ID, 1),
    defaultDockerImage: process.env.PTERO_DEFAULT_DOCKER_IMAGE || 'ghcr.io/pterodactyl/yolks:java_17',
    defaultStartup:
      process.env.PTERO_DEFAULT_STARTUP ||
      'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
    defaultEnv: parseJSONOrEmpty(process.env.PTERO_DEFAULT_ENV),
  },
  account: {
    emailDomain: process.env.ACCOUNT_EMAIL_DOMAIN || 'therynzo.in',
    defaultRole: (process.env.ACCOUNT_DEFAULT_ROLE || 'user').toLowerCase(),
  },
  bot: {
    ownerIds: parseList(process.env.OWNER_IDS),
    adminRoleIds: parseList(process.env.ADMIN_ROLE_IDS),
    nodeStatusChannelId: process.env.NODE_STATUS_CHANNEL_ID || '',
    nodeStatusIntervalMin: parseInteger(process.env.NODE_STATUS_INTERVAL_MIN, 3),
    logChannelId: process.env.LOG_CHANNEL_ID || '',
  },
  economy: {
    dailyMin: parseInteger(process.env.DAILY_REWARD_MIN, 20),
    dailyMax: parseInteger(process.env.DAILY_REWARD_MAX, 50),
    workMin: parseInteger(process.env.WORK_REWARD_MIN, 40),
    workMax: parseInteger(process.env.WORK_REWARD_MAX, 75),
    workCooldownMin: parseInteger(process.env.WORK_COOLDOWN_MIN, 30),
    robCooldownMin: parseInteger(process.env.ROB_COOLDOWN_MIN, 30),
    robSuccessRate: parseFloatValue(process.env.ROB_SUCCESS_RATE, 0.45),
    bankDepositFee: parseFloatValue(process.env.BANK_DEPOSIT_FEE, 0.02),
    bankWithdrawFee: parseFloatValue(process.env.BANK_WITHDRAW_FEE, 0.01),
    bankLimit: parseInteger(process.env.BANK_LIMIT, 50000),
  },
  database: {
    path: process.env.DATABASE_PATH || './data/hivecore.db',
  },
  logging: {
    level: process.env.LOG_LEVEL || 'info',
  },
  branding: {
    name: 'HiveCore',
    coinSymbol: 'NC',
    coinEmoji: '🪙',
    color: 0xf1c40f,
    successColor: 0x57f287,
    errorColor: 0xed4245,
    warnColor: 0xfee75c,
    infoColor: 0x5865f2,
    footer: 'HiveCore Coins • hivecore.host',
  },
};

function validateRequired() {
  const missing = [];
  if (!config.discord.token) missing.push('DISCORD_TOKEN');
  if (!config.discord.clientId) missing.push('DISCORD_CLIENT_ID');
  return missing;
}

module.exports = { config, validateRequired };
