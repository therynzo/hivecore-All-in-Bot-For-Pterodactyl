'use strict';

/**
 * Extracts a user-friendly error message from a Pterodactyl API failure.
 */
function describePteroError(err) {
  if (!err) return 'Unknown error';
  const data = err.response?.data;
  if (data?.errors && Array.isArray(data.errors) && data.errors.length > 0) {
    const first = data.errors[0];
    return first.detail || first.code || JSON.stringify(first);
  }
  if (typeof data === 'string') {
    return data.slice(0, 500);
  }
  if (err.response?.status) {
    return `${err.response.status} ${err.response.statusText || ''}`.trim();
  }
  return err.message || 'Unknown error';
}

module.exports = { describePteroError };
