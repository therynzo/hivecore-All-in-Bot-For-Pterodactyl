'use strict';

const axios = require('axios');
const { config } = require('../config/config');

/**
 * Application API client (admin operations).
 * Reference: https://dashflo.net/docs/api/pterodactyl/v1/
 */
function appClient() {
  if (!config.pterodactyl.panelUrl || !config.pterodactyl.appKey) {
    throw new Error('Pterodactyl application API is not configured (PTERO_PANEL_URL / PTERO_APP_API_KEY).');
  }
  return axios.create({
    baseURL: `${config.pterodactyl.panelUrl}/api/application`,
    headers: {
      Authorization: `Bearer ${config.pterodactyl.appKey}`,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
    timeout: 20000,
  });
}

/**
 * Client API client. If `apiKey` is provided, use it; otherwise fall back to the global key.
 */
function clientApi(apiKey) {
  const key = apiKey || config.pterodactyl.clientKey;
  if (!config.pterodactyl.panelUrl) {
    throw new Error('PTERO_PANEL_URL is not configured.');
  }
  if (!key) {
    throw new Error('No client API key available (provide a personal key via /link or set PTERO_CLIENT_API_KEY).');
  }
  return axios.create({
    baseURL: `${config.pterodactyl.panelUrl}/api/client`,
    headers: {
      Authorization: `Bearer ${key}`,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
    timeout: 20000,
  });
}

/* ---------- Application API helpers ---------- */

async function listNodes() {
  const { data } = await appClient().get('/nodes', { params: { per_page: 100 } });
  return data.data || [];
}

async function getNode(nodeId) {
  const { data } = await appClient().get(`/nodes/${nodeId}`);
  return data;
}

async function getAllocations(nodeId) {
  const all = [];
  let page = 1;
  for (;;) {
    const { data } = await appClient().get(`/nodes/${nodeId}/allocations`, {
      params: { page, per_page: 100 },
    });
    all.push(...(data.data || []));
    const totalPages = data.meta?.pagination?.total_pages || 1;
    if (page >= totalPages) break;
    page += 1;
  }
  return all;
}

async function findFreeAllocation(nodeId) {
  const allocations = await getAllocations(nodeId);
  return allocations.find((a) => a?.attributes?.assigned === false);
}

async function findAllocationOnAnyNodeInLocation(locationId) {
  const nodes = await listNodes();
  const candidates = nodes.filter((n) => n.attributes?.location_id === locationId);
  for (const node of candidates) {
    const free = await findFreeAllocation(node.attributes.id);
    if (free) return { node, allocation: free };
  }
  return null;
}

async function listUsers(query) {
  const { data } = await appClient().get('/users', {
    params: { 'filter[email]': query, per_page: 100 },
  });
  return data.data || [];
}

async function findUserByEmail(email) {
  const matches = await listUsers(email);
  return matches.find((u) => u.attributes?.email?.toLowerCase() === email.toLowerCase());
}

async function createUser({ email, username, firstName, lastName, password, rootAdmin = false }) {
  const { data } = await appClient().post('/users', {
    email,
    username,
    first_name: firstName,
    last_name: lastName,
    password,
    root_admin: rootAdmin,
  });
  return data;
}

async function deleteUser(userId) {
  await appClient().delete(`/users/${userId}`);
}

async function createServer(payload) {
  const { data } = await appClient().post('/servers', payload);
  return data;
}

async function getServer(serverId) {
  const { data } = await appClient().get(`/servers/${serverId}`);
  return data;
}

async function deleteServer(serverId, force = false) {
  await appClient().delete(`/servers/${serverId}${force ? '/force' : ''}`);
}

/* ---------- Client API helpers ---------- */

async function listClientServers(apiKey) {
  const { data } = await clientApi(apiKey).get('/');
  return data.data || [];
}

async function getClientServer(identifier, apiKey) {
  const { data } = await clientApi(apiKey).get(`/servers/${identifier}`);
  return data;
}

async function getServerResources(identifier, apiKey) {
  const { data } = await clientApi(apiKey).get(`/servers/${identifier}/resources`);
  return data;
}

async function sendPowerSignal(identifier, signal, apiKey) {
  if (!['start', 'stop', 'restart', 'kill'].includes(signal)) {
    throw new Error(`Invalid power signal: ${signal}`);
  }
  await clientApi(apiKey).post(`/servers/${identifier}/power`, { signal });
}

async function getRecentLogs(identifier, apiKey) {
  // The /resources endpoint does not return logs. Pull the last lines from the file API.
  const ax = clientApi(apiKey);
  try {
    const { data } = await ax.get(`/servers/${identifier}/files/contents`, {
      params: { file: '/logs/latest.log' },
      transformResponse: [(d) => d],
      responseType: 'text',
    });
    return typeof data === 'string' ? data : JSON.stringify(data);
  } catch {
    // Some eggs use a different log path; try the root server.log as a fallback.
    try {
      const { data } = await ax.get(`/servers/${identifier}/files/contents`, {
        params: { file: '/server.log' },
        transformResponse: [(d) => d],
        responseType: 'text',
      });
      return typeof data === 'string' ? data : JSON.stringify(data);
    } catch {
      return '';
    }
  }
}

async function sendCommand(identifier, command, apiKey) {
  await clientApi(apiKey).post(`/servers/${identifier}/command`, { command });
}

async function validateClientKey(apiKey) {
  await clientApi(apiKey).get('/');
}

module.exports = {
  appClient,
  clientApi,
  listNodes,
  getNode,
  getAllocations,
  findFreeAllocation,
  findAllocationOnAnyNodeInLocation,
  listUsers,
  findUserByEmail,
  createUser,
  deleteUser,
  createServer,
  getServer,
  deleteServer,
  listClientServers,
  getClientServer,
  getServerResources,
  sendPowerSignal,
  getRecentLogs,
  sendCommand,
  validateClientKey,
};
