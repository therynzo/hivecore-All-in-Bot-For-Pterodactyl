'use strict';

const { EmbedBuilder } = require('discord.js');
const { config } = require('../config/config');

function baseEmbed() {
  return new EmbedBuilder()
    .setColor(config.branding.color)
    .setFooter({ text: `${config.branding.footer} • Today` })
    .setTimestamp();
}

function success(title, description) {
  return baseEmbed()
    .setColor(config.branding.successColor)
    .setTitle(`✅ ${title}`)
    .setDescription(description || null);
}

function error(title, description) {
  return baseEmbed()
    .setColor(config.branding.errorColor)
    .setTitle(`❌ ${title}`)
    .setDescription(description || null);
}

function warn(title, description) {
  return baseEmbed()
    .setColor(config.branding.warnColor)
    .setTitle(`⚠️ ${title}`)
    .setDescription(description || null);
}

function info(title, description) {
  return baseEmbed()
    .setColor(config.branding.infoColor)
    .setTitle(`ℹ️ ${title}`)
    .setDescription(description || null);
}

function brand(title, description) {
  return baseEmbed()
    .setTitle(title)
    .setDescription(description || null);
}

function formatCoins(amount) {
  return `${config.branding.coinEmoji} **${Number(amount).toLocaleString('en-US')}** ${config.branding.coinSymbol}`;
}

module.exports = { baseEmbed, success, error, warn, info, brand, formatCoins };
