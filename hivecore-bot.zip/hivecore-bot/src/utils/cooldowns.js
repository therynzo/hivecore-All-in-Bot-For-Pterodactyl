'use strict';

const { Collection } = require('discord.js');

const cooldowns = new Collection();

/**
 * @returns {number} 0 if not on cooldown, else the remaining ms.
 */
function checkCooldown(scope, userId, durationMs) {
  const key = `${scope}:${userId}`;
  const now = Date.now();
  const expiresAt = cooldowns.get(key);
  if (expiresAt && expiresAt > now) {
    return expiresAt - now;
  }
  cooldowns.set(key, now + durationMs);
  return 0;
}

function clearCooldown(scope, userId) {
  cooldowns.delete(`${scope}:${userId}`);
}

function formatDuration(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const parts = [];
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  if (s || parts.length === 0) parts.push(`${s}s`);
  return parts.join(' ');
}

module.exports = { checkCooldown, clearCooldown, formatDuration };
