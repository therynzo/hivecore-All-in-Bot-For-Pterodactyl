'use strict';

const { PermissionsBitField } = require('discord.js');
const { config } = require('../config/config');

function isOwner(userId) {
  return config.bot.ownerIds.includes(userId);
}

function isAdmin(member) {
  if (!member) return false;
  if (isOwner(member.id)) return true;
  if (member.permissions?.has(PermissionsBitField.Flags.Administrator)) return true;
  if (member.roles?.cache?.some((role) => config.bot.adminRoleIds.includes(role.id))) {
    return true;
  }
  return false;
}

module.exports = { isOwner, isAdmin };
