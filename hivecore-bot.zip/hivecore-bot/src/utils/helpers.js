'use strict';

const crypto = require('crypto');

function randomInt(min, max) {
  const lo = Math.ceil(min);
  const hi = Math.floor(max);
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

function randomElement(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomString(length = 12) {
  return crypto.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length);
}

function randomPassword(length = 16) {
  // Cryptographically strong; mixes letters, digits, and a couple of symbols.
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
  const buf = crypto.randomBytes(length);
  let out = '';
  for (let i = 0; i < length; i++) {
    out += chars[buf[i] % chars.length];
  }
  return out;
}

function bytesToMB(bytes) {
  return Math.round((bytes / (1024 * 1024)) * 100) / 100;
}

function mbToBytes(mb) {
  return Math.round(mb * 1024 * 1024);
}

function progressBar(percent, size = 10) {
  const filled = Math.max(0, Math.min(size, Math.round((percent / 100) * size)));
  return '▰'.repeat(filled) + '▱'.repeat(size - filled);
}

function truncate(str, len = 1000) {
  if (!str) return '';
  if (str.length <= len) return str;
  return `${str.slice(0, len - 1)}…`;
}

function chunkString(str, size) {
  const chunks = [];
  for (let i = 0; i < str.length; i += size) {
    chunks.push(str.slice(i, i + size));
  }
  return chunks;
}

function safeJsonParse(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

module.exports = {
  randomInt,
  randomElement,
  randomString,
  randomPassword,
  bytesToMB,
  mbToBytes,
  progressBar,
  truncate,
  chunkString,
  safeJsonParse,
};
