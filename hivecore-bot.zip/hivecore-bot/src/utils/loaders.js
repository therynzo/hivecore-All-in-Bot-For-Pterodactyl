'use strict';

const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');
const logger = require('./logger');

function loadCommands(client) {
  client.commands = new Collection();
  const root = path.join(__dirname, '..', 'commands');
  if (!fs.existsSync(root)) return;

  for (const category of fs.readdirSync(root)) {
    const categoryPath = path.join(root, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    for (const file of fs.readdirSync(categoryPath)) {
      if (!file.endsWith('.js')) continue;
      const filePath = path.join(categoryPath, file);
      try {
        const command = require(filePath);
        if (!command?.data?.name || typeof command.execute !== 'function') {
          logger.warn({ filePath }, 'skipping invalid command (missing data/execute)');
          continue;
        }
        command.category = category;
        client.commands.set(command.data.name, command);
      } catch (err) {
        logger.error({ filePath, err: err.message }, 'failed to load command');
      }
    }
  }

  logger.info({ count: client.commands.size }, 'commands loaded');
}

function loadEvents(client) {
  const root = path.join(__dirname, '..', 'events');
  if (!fs.existsSync(root)) return;

  for (const file of fs.readdirSync(root)) {
    if (!file.endsWith('.js')) continue;
    const filePath = path.join(root, file);
    const event = require(filePath);
    if (!event?.name || typeof event.execute !== 'function') {
      logger.warn({ filePath }, 'skipping invalid event');
      continue;
    }
    if (event.once) {
      client.once(event.name, (...args) => event.execute(client, ...args));
    } else {
      client.on(event.name, (...args) => event.execute(client, ...args));
    }
  }

  logger.info('events loaded');
}

module.exports = { loadCommands, loadEvents };
